package com.flybrain.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class BrainGameView extends View {

    private enum Screen {
        MENU, GAME, BRAIN, EDITOR, SLEEP
    }

    private enum Kind {
        SPIKE, DOUBLE_SPIKE, SAW,
        COIN, FOOD, ORB, PAD,
        PORTAL_GRAVITY, PORTAL_SPEED,
        PORTAL_CUBE, PORTAL_SHIP, PORTAL_FLY, PORTAL_WAVE, PORTAL_UFO,
        FINISH
    }

    private static class Obj {
        float x;
        float w;
        float h;
        Kind kind;
        boolean used;

        Obj(float x, Kind kind) {
            this.x = x;
            this.kind = kind;
            this.used = false;

            w = 70f;
            h = 82f;

            if (kind == Kind.DOUBLE_SPIKE) w = 105f;
            if (kind == Kind.SAW) { w = 82f; h = 82f; }
            if (kind == Kind.COIN || kind == Kind.FOOD || kind == Kind.ORB) {
                w = 54f; h = 54f;
            }
            if (kind == Kind.PAD) { w = 96f; h = 24f; }
            if (kind.name().startsWith("PORTAL")) { w = 58f; h = 150f; }
            if (kind == Kind.FINISH) { w = 24f; h = 220f; }
        }
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final ArrayList<Obj> objects = new ArrayList<>();
    private final ArrayList<Obj> customObjects = new ArrayList<>();

    private SharedPreferences prefs;
    private PyObject bridge;
    private Bitmap flyBitmap;

    private Screen screen = Screen.MENU;
    private Screen screenBeforeSleep = Screen.MENU;

    private float groundY = 0f;
    private float flyX = 210f;
    private float flyY = 0f;
    private float flyVy = 0f;
    private final float flyW = 90f;
    private final float flyH = 72f;

    private float worldSpeed = 390f;
    private float speedMultiplier = 1f;
    private float gravitySign = 1f;
    private float progress = 0f;

    private String mode = "cube";
    private String levelId = "story_1";

    private int score = 0;
    private int deaths = 0;
    private int coins = 0;
    private int generation = 1;

    private boolean dead = false;
    private boolean aiEnabled = true;
    private boolean endless = false;

    private long deadAt = 0L;
    private long lastFrame = 0L;
    private long lastBrain = 0L;

    private String lastAction = "wait";
    private String goal = "progress";
    private float confidence = 0f;
    private float novelty = 0f;

    private JSONObject report = new JSONObject();
    private JSONObject sleepSummary = new JSONObject();

    private Kind editorKind = Kind.SPIKE;
    private int editorPlaced = 0;

    private final RectF playBtn = new RectF();
    private final RectF endlessBtn = new RectF();
    private final RectF editorBtn = new RectF();
    private final RectF brainBtn = new RectF();

    private final RectF backBtn = new RectF();
    private final RectF sleepBtn = new RectF();
    private final RectF wakeBtn = new RectF();
    private final RectF resetBtn = new RectF();
    private final RectF aiBtn = new RectF();
    private final RectF kindBtn = new RectF();
    private final RectF testBtn = new RectF();
    private final RectF clearBtn = new RectF();

    public BrainGameView(Context context) {
        super(context);
        setFocusable(true);

        text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));

        prefs = context.getSharedPreferences("flybrain_game_v2_1", Context.MODE_PRIVATE);

        flyBitmap = BitmapFactory.decodeResource(
            getResources(),
            getResources().getIdentifier("fly", "drawable", context.getPackageName())
        );

        try {
            Python py = Python.getInstance();
            bridge = py.getModule("android_bridge");
            bridge.callAttr("init_brain", prefs.getString("brain_json", ""));
            refreshReport();
        } catch (Throwable t) {
            lastAction = "python-error";
        }
    }

    private void refreshReport() {
        if (bridge == null) return;
        try {
            report = new JSONObject(bridge.callAttr("report").toString());
        } catch (Exception ignored) {
        }
    }

    public void saveBrain() {
        if (bridge == null) return;
        try {
            prefs.edit()
                .putString("brain_json", bridge.callAttr("save_json").toString())
                .apply();
        } catch (Exception ignored) {
        }
    }

    public void resumeGame() {
        lastFrame = 0L;
        invalidate();
    }

    private void startStory() {
        endless = false;
        levelId = "story_1";
        startGame();
    }

    private void startEndless() {
        endless = true;
        levelId = "endless";
        startGame();
    }

    private void startCustom() {
        endless = false;
        levelId = "custom";
        startGame();
    }

    private void startGame() {
        screen = Screen.GAME;
        dead = false;
        progress = 0f;
        score = 0;
        coins = 0;
        mode = "cube";
        gravitySign = 1f;
        speedMultiplier = 1f;

        if (groundY > 0f) {
            flyY = groundY - flyH;
        }
        flyVy = 0f;

        objects.clear();

        float x = Math.max(900f, getWidth() + 220f);

        if (levelId.equals("custom") && !customObjects.isEmpty()) {
            for (Obj c : customObjects) {
                Obj n = new Obj(x + c.x, c.kind);
                objects.add(n);
            }
            objects.add(new Obj(x + 3600f, Kind.FINISH));

        } else if (endless) {
            for (int i = 0; i < 14; i++) {
                objects.add(randomObj(x + i * 390f));
            }

        } else {
            addStoryObjects(x);
        }

        if (bridge != null) {
            try {
                bridge.callAttr("start_route", levelId);
            } catch (Exception ignored) {
            }
        }
    }

    private void addStoryObjects(float x) {
        objects.add(new Obj(x, Kind.SPIKE));
        objects.add(new Obj(x + 380, Kind.COIN));
        objects.add(new Obj(x + 700, Kind.DOUBLE_SPIKE));
        objects.add(new Obj(x + 980, Kind.PAD));
        objects.add(new Obj(x + 1280, Kind.PORTAL_SHIP));
        objects.add(new Obj(x + 1600, Kind.SAW));
        objects.add(new Obj(x + 1930, Kind.FOOD));
        objects.add(new Obj(x + 2260, Kind.PORTAL_GRAVITY));
        objects.add(new Obj(x + 2580, Kind.ORB));
        objects.add(new Obj(x + 2900, Kind.PORTAL_WAVE));
        objects.add(new Obj(x + 3230, Kind.SAW));
        objects.add(new Obj(x + 3550, Kind.PORTAL_CUBE));
        objects.add(new Obj(x + 3890, Kind.DOUBLE_SPIKE));
        objects.add(new Obj(x + 4400, Kind.FINISH));
    }

    private Obj randomObj(float x) {
        Kind[] kinds = {
            Kind.SPIKE, Kind.DOUBLE_SPIKE, Kind.SAW,
            Kind.COIN, Kind.FOOD, Kind.ORB, Kind.PAD,
            Kind.PORTAL_GRAVITY, Kind.PORTAL_SPEED,
            Kind.PORTAL_CUBE, Kind.PORTAL_SHIP,
            Kind.PORTAL_FLY, Kind.PORTAL_WAVE, Kind.PORTAL_UFO
        };
        return new Obj(x, kinds[rng.nextInt(kinds.length)]);
    }

    private String objectName(Kind k) {
        switch (k) {
            case DOUBLE_SPIKE: return "double_spike";
            case SAW: return "saw";
            case COIN: return "coin";
            case FOOD: return "food";
            case ORB: return "orb";
            case PAD: return "pad";
            case PORTAL_GRAVITY: return "portal_gravity";
            case PORTAL_SPEED: return "portal_speed";
            case PORTAL_CUBE: return "portal_cube";
            case PORTAL_SHIP: return "portal_ship";
            case PORTAL_FLY: return "portal_fly";
            case PORTAL_WAVE: return "portal_wave";
            case PORTAL_UFO: return "portal_ufo";
            case FINISH: return "finish";
            default: return "spike";
        }
    }

    private float danger(Kind k) {
        if (k == Kind.SPIKE || k == Kind.DOUBLE_SPIKE || k == Kind.SAW) return 1f;
        return 0.06f;
    }

    private float value(Kind k) {
        if (k == Kind.COIN) return 0.65f;
        if (k == Kind.FOOD) return 1f;
        return 0f;
    }

    private Obj nearestThreat() {
        Obj best = null;
        float bestDx = Float.MAX_VALUE;

        for (Obj o : objects) {
            if (o.used) continue;
            float dx = o.x - flyX;
            if (dx > -o.w && dx < bestDx) {
                bestDx = dx;
                best = o;
            }
        }
        return best;
    }

    private float beatPhase() {
        double seconds = System.nanoTime() / 1_000_000_000.0;
        double beatLength = 60.0 / 150.0;
        return (float)((seconds % beatLength) / beatLength);
    }

    private void askBrain(Obj o, long now) {
        if (!aiEnabled || bridge == null || o == null || dead || screen != Screen.GAME) return;
        if (now - lastBrain < 50_000_000L) return;

        lastBrain = now;

        float dx = Math.max(0f, o.x - flyX);
        float dist = Math.min(1f, dx / 600f);

        try {
            JSONObject j = new JSONObject(
                bridge.callAttr(
                    "decide",
                    objectName(o.kind),
                    dist,
                    Math.min(1f, worldSpeed * speedMultiplier / 800f),
                    danger(o.kind),
                    progress,
                    mode,
                    gravitySign,
                    speedMultiplier,
                    levelId,
                    value(o.kind),
                    "level_music",
                    150.0,
                    beatPhase()
                ).toString()
            );

            lastAction = j.optString("action", "wait");
            confidence = (float)j.optDouble("confidence", 0);
            novelty = (float)j.optDouble("novelty", 0);
            goal = j.optString("goal", "progress");

            if (j.optBoolean("jump", false)) {
                jump();
            }

            if (j.optBoolean("hold", false)) {
                continuousControl(true);
            }

        } catch (Exception e) {
            lastAction = "brain-error";
        }
    }

    private void jump() {
        if (dead || screen != Screen.GAME) return;

        if (mode.equals("cube") || mode.equals("ufo")) {
            if (Math.abs(flyY - (groundY - flyH)) < 24f || mode.equals("ufo")) {
                flyVy = -720f * gravitySign;
            }
        }
    }

    private void continuousControl(boolean active) {
        if (!active) return;

        if (mode.equals("ship") || mode.equals("fly")) {
            flyVy += -58f * gravitySign;

        } else if (mode.equals("wave")) {
            flyVy = -520f * gravitySign;
        }
    }

    private boolean hits(Obj o) {
        RectF f = new RectF(
            flyX + 10, flyY + 8,
            flyX + flyW - 10, flyY + flyH - 8
        );

        float oy = groundY - o.h;

        if (o.kind == Kind.COIN || o.kind == Kind.FOOD || o.kind == Kind.ORB) {
            oy = groundY - 170f;
        }

        RectF r = new RectF(o.x, oy, o.x + o.w, oy + o.h);
        return RectF.intersects(f, r);
    }

    private void applyObject(Obj o, long now) {
        if (o.used) return;

        if (o.kind == Kind.COIN) {
            o.used = true;
            coins++;
            score += 5;
            learn(o, true);
            return;
        }

        if (o.kind == Kind.FOOD) {
            o.used = true;
            score += 3;
            try {
                if (bridge != null) bridge.callAttr("reward_food", 0.45);
            } catch (Exception ignored) {
            }
            return;
        }

        if (o.kind == Kind.PAD) {
            o.used = true;
            flyVy = -900f * gravitySign;
            learn(o, true);
            return;
        }

        if (o.kind == Kind.ORB) {
            o.used = true;
            flyVy = -780f * gravitySign;
            learn(o, true);
            return;
        }

        if (o.kind == Kind.PORTAL_GRAVITY) {
            o.used = true;
            gravitySign *= -1f;
            try {
                if (bridge != null) bridge.callAttr("portal", "gravity_flip");
            } catch (Exception ignored) {
            }
            return;
        }

        if (o.kind == Kind.PORTAL_SPEED) {
            o.used = true;
            speedMultiplier = speedMultiplier < 1.5f ? 2f : 1f;
            try {
                if (bridge != null) bridge.callAttr("portal", "speed", speedMultiplier);
            } catch (Exception ignored) {
            }
            return;
        }

        if (o.kind == Kind.PORTAL_CUBE) { setModePortal(o, "cube"); return; }
        if (o.kind == Kind.PORTAL_SHIP) { setModePortal(o, "ship"); return; }
        if (o.kind == Kind.PORTAL_FLY)  { setModePortal(o, "fly");  return; }
        if (o.kind == Kind.PORTAL_WAVE) { setModePortal(o, "wave"); return; }
        if (o.kind == Kind.PORTAL_UFO)  { setModePortal(o, "ufo");  return; }

        if (o.kind == Kind.FINISH) {
            o.used = true;
            finishLevel(true);
            return;
        }

        die(o, now);
    }

    private void setModePortal(Obj o, String newMode) {
        o.used = true;
        mode = newMode;
        try {
            if (bridge != null) bridge.callAttr("portal", "mode", newMode);
        } catch (Exception ignored) {
        }
    }

    private void learn(Obj o, boolean success) {
        if (bridge == null) return;
        try {
            bridge.callAttr(
                "learn_result",
                objectName(o.kind),
                lastAction,
                success,
                progress,
                0.42,
                0.85
            );
        } catch (Exception ignored) {
        }
    }

    private void die(Obj o, long now) {
        if (dead) return;

        dead = true;
        deaths++;
        deadAt = now;

        try {
            if (bridge != null) {
                float dist = Math.min(1f, Math.abs(o.x - flyX) / 500f);
                bridge.callAttr(
                    "death",
                    objectName(o.kind),
                    lastAction,
                    progress,
                    dist,
                    "collision"
                );
                bridge.callAttr("finish_route", false, progress, -0.8);
            }
        } catch (Exception ignored) {
        }

        saveBrain();
    }

    private void finishLevel(boolean success) {
        try {
            if (bridge != null) {
                bridge.callAttr("finish_route", success, progress, success ? 1.0 : -0.8);
            }
        } catch (Exception ignored) {
        }

        saveBrain();

        if (success) {
            generation++;
            screen = Screen.MENU;
            refreshReport();
        }
    }

    private void enterSleep() {
        if (bridge == null) return;

        screenBeforeSleep = screen;
        screen = Screen.SLEEP;

        try {
            sleepSummary = new JSONObject(
                bridge.callAttr("sleep_brain").toString()
            );
            saveBrain();
            refreshReport();

        } catch (Exception e) {
            sleepSummary = new JSONObject();
            try {
                sleepSummary.put("error", e.toString());
            } catch (Exception ignored) {
            }
        }

        invalidate();
    }

    private void wakeUp() {
        screen = screenBeforeSleep;
        lastFrame = 0L;
        invalidate();
    }

    private void resetBrain() {
        try {
            if (bridge != null) bridge.callAttr("factory_reset");
        } catch (Exception ignored) {
        }

        prefs.edit().remove("brain_json").apply();
        refreshReport();
        generation = 1;
        deaths = 0;
        score = 0;
        coins = 0;
    }

    private void update(float dt, long now) {
        if (screen != Screen.GAME) return;
        if (getWidth() <= 0 || getHeight() <= 0) return;

        if (groundY == 0f) {
            groundY = getHeight() * 0.78f;
            flyY = groundY - flyH;
        }

        if (dead) {
            if (now - deadAt > 850_000_000L) {
                generation++;
                startGame();
            }
            return;
        }

        progress = Math.min(1f, progress + dt * 0.028f);

        float g = 1850f * gravitySign;
        flyVy += g * dt;

        if (mode.equals("wave") && !aiEnabled) {
            flyVy = 520f * gravitySign;
        }

        flyY += flyVy * dt;

        float normalGround = groundY - flyH;
        float ceiling = 40f;

        if (gravitySign > 0f) {
            if (flyY > normalGround) {
                flyY = normalGround;
                flyVy = 0f;
            }
        } else {
            if (flyY < ceiling) {
                flyY = ceiling;
                flyVy = 0f;
            }
        }

        if (flyY < 20f) flyY = 20f;
        if (flyY > groundY - flyH) flyY = groundY - flyH;

        askBrain(nearestThreat(), now);

        float farthest = getWidth();

        for (Obj o : objects) {
            o.x -= worldSpeed * speedMultiplier * dt;
            farthest = Math.max(farthest, o.x);

            if (!o.used && hits(o)) {
                applyObject(o, now);
            }

            if (!o.used && o.x + o.w < flyX - 30f) {
                if (danger(o.kind) > 0.5f) {
                    o.used = true;
                    score++;
                    learn(o, true);
                }
            }
        }

        Iterator<Obj> it = objects.iterator();
        int removed = 0;

        while (it.hasNext()) {
            Obj o = it.next();
            if (o.x + o.w < -150f) {
                it.remove();
                removed++;
            }
        }

        if (endless) {
            for (int i = 0; i < removed; i++) {
                farthest = Math.max(farthest, getWidth() + 450f);
                objects.add(randomObj(farthest + 320f + rng.nextInt(220)));
            }
        }
    }

    private void drawButton(Canvas c, RectF r, String label) {
        p.setColor(Color.rgb(42, 52, 74));
        c.drawRoundRect(r, 18, 18, p);

        text.setColor(Color.WHITE);
        text.setTextSize(22f);
        text.setTextAlign(Paint.Align.CENTER);
        c.drawText(label, r.centerX(), r.centerY() + 8f, text);
        text.setTextAlign(Paint.Align.LEFT);
    }

    private void drawMenu(Canvas c) {
        c.drawColor(Color.rgb(8, 11, 18));

        text.setColor(Color.rgb(124, 255, 155));
        text.setTextSize(54f);
        c.drawText("FLYBRAIN", 52, 90, text);

        text.setColor(Color.WHITE);
        text.setTextSize(24f);
        c.drawText("AI platformer laboratory", 56, 128, text);

        float cx = getWidth() / 2f;
        playBtn.set(cx - 250, 180, cx - 20, 255);
        endlessBtn.set(cx + 20, 180, cx + 250, 255);
        editorBtn.set(cx - 250, 280, cx - 20, 355);
        brainBtn.set(cx + 20, 280, cx + 250, 355);
        sleepBtn.set(cx - 115, 390, cx + 115, 460);

        drawButton(c, playBtn, "STORY");
        drawButton(c, endlessBtn, "ENDLESS");
        drawButton(c, editorBtn, "EDITOR");
        drawButton(c, brainBtn, "BRAIN");
        drawButton(c, sleepBtn, "SLEEP");

        text.setColor(Color.LTGRAY);
        text.setTextSize(20f);
        c.drawText(
            "Modes: cube / ship / fly / wave / ufo",
            56, getHeight() - 70, text
        );
    }

    private void drawGame(Canvas c) {
        c.drawColor(Color.rgb(8, 11, 18));

        if (groundY == 0f) {
            groundY = getHeight() * 0.78f;
            flyY = groundY - flyH;
        }

        p.setColor(Color.rgb(20, 29, 45));
        p.setStrokeWidth(1f);

        for (int x = 0; x < getWidth(); x += 70) {
            c.drawLine(x, 0, x, groundY, p);
        }
        for (int y = 0; y < groundY; y += 70) {
            c.drawLine(0, y, getWidth(), y, p);
        }

        p.setColor(Color.rgb(60, 235, 135));
        p.setStrokeWidth(5f);
        c.drawLine(0, groundY, getWidth(), groundY, p);

        for (Obj o : objects) {
            if (o.used) continue;
            drawObject(c, o);
        }

        if (flyBitmap != null) {
            Rect src = new Rect(0, 0, flyBitmap.getWidth(), flyBitmap.getHeight());
            RectF dst = new RectF(flyX, flyY, flyX + flyW, flyY + flyH);
            c.drawBitmap(flyBitmap, src, dst, p);
        } else {
            p.setColor(Color.YELLOW);
            c.drawOval(new RectF(flyX, flyY, flyX + flyW, flyY + flyH), p);
        }

        p.setColor(Color.argb(190, 5, 8, 15));
        c.drawRoundRect(new RectF(18, 15, 730, 180), 22, 22, p);

        text.setColor(Color.WHITE);
        text.setTextSize(24f);
        c.drawText("FlyBrain Game v2.1", 38, 48, text);

        text.setTextSize(19f);
        c.drawText(
            String.format(
                Locale.US,
                "score %d   deaths %d   coins %d   gen %d",
                score, deaths, coins, generation
            ),
            38, 78, text
        );

        c.drawText(
            String.format(
                Locale.US,
                "mode %-5s action %-8s conf %.2f novelty %.2f",
                mode, lastAction, confidence, novelty
            ),
            38, 107, text
        );

        c.drawText("goal: " + goal, 38, 135, text);

        p.setColor(Color.rgb(28, 40, 58));
        c.drawRoundRect(new RectF(38, 150, 650, 164), 7, 7, p);

        p.setColor(Color.rgb(124, 255, 155));
        c.drawRoundRect(
            new RectF(38, 150, 38 + 612 * progress, 164),
            7, 7, p
        );

        backBtn.set(getWidth() - 310, 24, getWidth() - 215, 82);
        aiBtn.set(getWidth() - 205, 24, getWidth() - 110, 82);
        sleepBtn.set(getWidth() - 100, 24, getWidth() - 15, 82);

        drawButton(c, backBtn, "BACK");
        drawButton(c, aiBtn, aiEnabled ? "AI ON" : "AI OFF");
        drawButton(c, sleepBtn, "SLEEP");

        if (dead) {
            p.setColor(Color.argb(175, 20, 0, 5));
            c.drawRect(0, 0, getWidth(), getHeight(), p);

            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(52f);
            text.setColor(Color.rgb(255, 100, 115));
            c.drawText(
                "DEATH MEMORY SAVED",
                getWidth() / 2f,
                getHeight() / 2f,
                text
            );

            text.setTextSize(23f);
            text.setColor(Color.WHITE);
            c.drawText(
                "next generation will use this mistake",
                getWidth() / 2f,
                getHeight() / 2f + 42,
                text
            );

            text.setTextAlign(Paint.Align.LEFT);
        }
    }

    private void drawObject(Canvas c, Obj o) {
        float y = groundY - o.h;

        if (o.kind == Kind.COIN || o.kind == Kind.FOOD || o.kind == Kind.ORB) {
            y = groundY - 170f;
        }

        if (o.kind == Kind.SAW) {
            p.setColor(Color.rgb(255, 100, 100));
            c.drawCircle(o.x + o.w / 2f, y + o.h / 2f, o.w / 2f, p);

            p.setColor(Color.rgb(8, 11, 18));
            c.drawCircle(o.x + o.w / 2f, y + o.h / 2f, o.w / 5f, p);
            return;
        }

        if (o.kind == Kind.SPIKE || o.kind == Kind.DOUBLE_SPIKE) {
            p.setColor(Color.rgb(255, 90, 105));
            Path path = new Path();
            path.moveTo(o.x, groundY);
            path.lineTo(o.x + o.w / 2f, y);
            path.lineTo(o.x + o.w, groundY);
            path.close();
            c.drawPath(path, p);
            return;
        }

        if (o.kind == Kind.COIN) p.setColor(Color.rgb(255, 220, 60));
        else if (o.kind == Kind.FOOD) p.setColor(Color.rgb(100, 255, 150));
        else if (o.kind == Kind.ORB) p.setColor(Color.rgb(100, 180, 255));
        else if (o.kind == Kind.PAD) p.setColor(Color.rgb(255, 180, 80));
        else if (o.kind == Kind.FINISH) p.setColor(Color.WHITE);
        else p.setColor(Color.rgb(155, 105, 255));

        c.drawRoundRect(
            new RectF(o.x, y, o.x + o.w, y + o.h),
            16, 16, p
        );
    }

    private void drawBrain(Canvas c) {
        c.drawColor(Color.rgb(7, 10, 18));
        refreshReport();

        backBtn.set(20, 20, 120, 75);
        sleepBtn.set(getWidth() - 125, 20, getWidth() - 20, 75);
        resetBtn.set(getWidth() - 250, 20, getWidth() - 140, 75);

        drawButton(c, backBtn, "BACK");
        drawButton(c, resetBtn, "RESET");
        drawButton(c, sleepBtn, "SLEEP");

        text.setColor(Color.rgb(124, 255, 155));
        text.setTextSize(42f);
        c.drawText("BRAIN", 42, 125, text);

        text.setColor(Color.WHITE);
        text.setTextSize(21f);

        int y = 165;

        String[] lines = {
            "version: " + report.optInt("version", 12),
            "curiosity: " + fmt(report.optDouble("curiosity", 0)),
            "dopamine: " + fmt(report.optDouble("dopamine", 0)),
            "energy: " + fmt(report.optDouble("energy", 0)),
            "dominant goal: " + report.optString("dominant_goal", ""),
            "total deaths: " + report.optInt("total_deaths", 0),
            "total spikes: " + report.optInt("total_spikes", 0)
        };

        for (String s : lines) {
            c.drawText(s, 48, y, text);
            y += 31;
        }

        JSONObject counts = report.optJSONObject("memory_counts");

        if (counts != null) {
            y += 12;
            text.setColor(Color.rgb(150, 190, 255));
            c.drawText("MEMORY", 48, y, text);
            y += 32;

            String[] mem = {
                "visual objects: " + counts.optInt("visual_objects", 0),
                "patterns: " + counts.optInt("patterns", 0),
                "episodes: " + counts.optInt("episodes", 0),
                "routes: " + counts.optInt("routes", 0),
                "global skills: " + counts.optInt("global_skills", 0),
                "family skills: " + counts.optInt("family_skills", 0),
                "death contexts: " + counts.optInt("death_contexts", 0),
                "replay: " + counts.optInt("replay", 0)
            };

            text.setColor(Color.WHITE);

            for (String s : mem) {
                c.drawText(s, 48, y, text);
                y += 29;
            }
        }
    }

    private void drawEditor(Canvas c) {
        c.drawColor(Color.rgb(10, 13, 21));

        backBtn.set(20, 18, 115, 72);
        kindBtn.set(130, 18, 350, 72);
        testBtn.set(getWidth() - 245, 18, getWidth() - 135, 72);
        clearBtn.set(getWidth() - 120, 18, getWidth() - 20, 72);

        drawButton(c, backBtn, "BACK");
        drawButton(c, kindBtn, editorKind.name());
        drawButton(c, testBtn, "TEST");
        drawButton(c, clearBtn, "CLEAR");

        text.setColor(Color.WHITE);
        text.setTextSize(21f);
        c.drawText(
            "Tap the field to place objects. Placed: " + editorPlaced,
            28, 110, text
        );

        float baseY = getHeight() * 0.78f;

        p.setColor(Color.rgb(60, 235, 135));
        p.setStrokeWidth(4f);
        c.drawLine(0, baseY, getWidth(), baseY, p);

        for (Obj o : customObjects) {
            Obj draw = new Obj(o.x, o.kind);
            drawObjectAtEditor(c, draw, baseY);
        }
    }

    private void drawObjectAtEditor(Canvas c, Obj o, float baseY) {
        float oldGround = groundY;
        groundY = baseY;
        drawObject(c, o);
        groundY = oldGround;
    }

    private void drawSleep(Canvas c) {
        c.drawColor(Color.rgb(5, 8, 18));

        text.setTextAlign(Paint.Align.CENTER);
        text.setColor(Color.rgb(140, 170, 255));
        text.setTextSize(52f);
        c.drawText("BRAIN SLEEP", getWidth() / 2f, 95, text);

        text.setTextSize(23f);
        text.setColor(Color.WHITE);
        c.drawText(
            "offline replay + memory consolidation completed",
            getWidth() / 2f, 135, text
        );

        int replayed = sleepSummary.optInt("replayed", 0);
        int replaySize = sleepSummary.optInt("replay_size", 0);

        JSONObject routes = sleepSummary.optJSONObject("routes");
        JSONObject globals = sleepSummary.optJSONObject("global_skills");
        JSONObject memory = sleepSummary.optJSONObject("memory");

        int y = 205;

        text.setTextSize(26f);
        text.setColor(Color.rgb(124, 255, 155));

        String[] lines = {
            "replayed experiences: " + replayed,
            "replay memory size: " + replaySize,
            "routes kept: " + (routes != null ? routes.optInt("routes", 0) : 0),
            "global skills: " + (globals != null ? globals.optInt("skills", 0) : 0),
            "episodes: " + (memory != null ? memory.optInt("episodes", 0) : 0),
            "patterns: " + (memory != null ? memory.optInt("patterns", 0) : 0)
        };

        for (String s : lines) {
            c.drawText(s, getWidth() / 2f, y, text);
            y += 42;
        }

        wakeBtn.set(
            getWidth() / 2f - 130,
            getHeight() - 110,
            getWidth() / 2f + 130,
            getHeight() - 42
        );

        drawButton(c, wakeBtn, "WAKE");

        text.setTextAlign(Paint.Align.LEFT);
    }

    private String fmt(double v) {
        return String.format(Locale.US, "%.3f", v);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);

        long now = System.nanoTime();

        if (lastFrame == 0L) lastFrame = now;

        float dt = Math.min(
            0.035f,
            (now - lastFrame) / 1_000_000_000f
        );

        lastFrame = now;

        update(dt, now);

        if (screen == Screen.MENU) drawMenu(c);
        else if (screen == Screen.GAME) drawGame(c);
        else if (screen == Screen.BRAIN) drawBrain(c);
        else if (screen == Screen.EDITOR) drawEditor(c);
        else drawSleep(c);

        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_DOWN) return true;

        float x = e.getX();
        float y = e.getY();

        if (screen == Screen.MENU) {
            if (playBtn.contains(x, y)) startStory();
            else if (endlessBtn.contains(x, y)) startEndless();
            else if (editorBtn.contains(x, y)) screen = Screen.EDITOR;
            else if (brainBtn.contains(x, y)) screen = Screen.BRAIN;
            else if (sleepBtn.contains(x, y)) enterSleep();

        } else if (screen == Screen.GAME) {
            if (backBtn.contains(x, y)) {
                saveBrain();
                screen = Screen.MENU;

            } else if (aiBtn.contains(x, y)) {
                aiEnabled = !aiEnabled;

            } else if (sleepBtn.contains(x, y)) {
                enterSleep();

            } else {
                if (mode.equals("wave")) {
                    continuousControl(true);
                } else {
                    jump();
                }
            }

        } else if (screen == Screen.BRAIN) {
            if (backBtn.contains(x, y)) screen = Screen.MENU;
            else if (sleepBtn.contains(x, y)) enterSleep();
            else if (resetBtn.contains(x, y)) resetBrain();

        } else if (screen == Screen.EDITOR) {
            if (backBtn.contains(x, y)) {
                screen = Screen.MENU;

            } else if (kindBtn.contains(x, y)) {
                Kind[] list = {
                    Kind.SPIKE, Kind.DOUBLE_SPIKE, Kind.SAW,
                    Kind.COIN, Kind.FOOD, Kind.ORB, Kind.PAD,
                    Kind.PORTAL_GRAVITY, Kind.PORTAL_SPEED,
                    Kind.PORTAL_CUBE, Kind.PORTAL_SHIP,
                    Kind.PORTAL_FLY, Kind.PORTAL_WAVE, Kind.PORTAL_UFO
                };

                int idx = 0;
                for (int i = 0; i < list.length; i++) {
                    if (list[i] == editorKind) idx = i;
                }
                editorKind = list[(idx + 1) % list.length];

            } else if (testBtn.contains(x, y)) {
                startCustom();

            } else if (clearBtn.contains(x, y)) {
                customObjects.clear();
                editorPlaced = 0;

            } else if (y > 120) {
                Obj o = new Obj(Math.max(120f, x), editorKind);
                customObjects.add(o);
                editorPlaced++;
            }

        } else if (screen == Screen.SLEEP) {
            if (wakeBtn.contains(x, y)) {
                wakeUp();
            }
        }

        invalidate();
        return true;
    }
}
