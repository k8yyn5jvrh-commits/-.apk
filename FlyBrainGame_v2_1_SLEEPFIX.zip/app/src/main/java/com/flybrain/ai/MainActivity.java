package com.flybrain.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

public class MainActivity extends Activity {
    private BrainGameView gameView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        try {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(this));
            }

            if (android.os.Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    );
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
            }

            gameView = new BrainGameView(this);
            setContentView(gameView);

        } catch (Throwable t) {
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(Color.rgb(30, 5, 10));
            tv.setTextSize(15);
            tv.setPadding(30, 30, 30, 30);
            tv.setText("FlyBrain startup error:\n\n" + t.toString());

            ScrollView s = new ScrollView(this);
            s.addView(tv);
            setContentView(s);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (gameView != null) gameView.saveBrain();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameView != null) gameView.resumeGame();
    }
}
