import json
from fly_brain_model_v12 import FlyBrainModel

brain = None

def _safe_load(saved_json):
    if not saved_json:
        return {}
    try:
        obj = json.loads(saved_json)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}

def _ensure():
    global brain
    if brain is None:
        brain = FlyBrainModel()
    return brain

def init_brain(saved_json=""):
    global brain
    brain = FlyBrainModel(_safe_load(saved_json))
    return report()

def decide(object_type, distance, speed, danger, progress,
           mode="cube", gravity=1.0, speed_multiplier=1.0,
           level_id="level_1", object_value=0.0,
           music_id="game", bpm=150.0, beat_phase=0.0):
    b = _ensure()
    out = b.decide_game_action(
        object_type=str(object_type),
        distance=float(distance),
        speed=float(speed),
        danger=float(danger),
        vision_motion=max(.05, min(1.0, float(speed))),
        looming=max(0.0, min(1.0, 1.0 - float(distance))),
        game_mode=str(mode),
        gravity=float(gravity),
        speed_multiplier=float(speed_multiplier),
        level_id=str(level_id),
        level_progress=float(progress),
        object_value=float(object_value),
        music_id=str(music_id),
        bpm=float(bpm),
        beat_phase=float(beat_phase),
        beat_strength=1.0,
    )
    compact = {
        "action": out.get("action", "wait"),
        "jump": bool(out.get("jump", False)),
        "hold": bool(out.get("hold", False)),
        "vertical": float(out.get("vertical", 0.0)),
        "confidence": float(out.get("confidence", 0.0)),
        "novelty": float(out.get("novelty", 0.0)),
        "goal": out.get("dominant_goal", ""),
        "route": out.get("route", {}),
        "global_skill": out.get("global_skill", {}),
        "family_skill": out.get("family_skill", {}),
        "death": out.get("death_correction", {}),
        "imagination": out.get("imagination", {}),
    }
    return json.dumps(compact, ensure_ascii=False)

def learn_result(object_type, action, success, progress,
                 timing=.42, control_strength=.8):
    b = _ensure()
    b.learn_game_result(
        object_type=str(object_type),
        action=str(action),
        success=bool(success),
        timing=float(timing),
        progress=float(progress),
        game_mode=b.game_mode,
        control_strength=float(control_strength),
    )
    return report()

def death(object_type, action, progress, distance, cause="collision"):
    b = _ensure()
    out = b.on_death(
        object_type=str(object_type),
        distance=float(distance),
        progress=float(progress),
        action=str(action),
        cause=str(cause),
    )
    return json.dumps(out, ensure_ascii=False)

def reward_food(amount=.4):
    b = _ensure()
    try:
        b.reward_food(float(amount))
    except Exception:
        b.add_reward(float(amount))
    return report()

def start_route(level_id):
    b = _ensure()
    try:
        b.start_episode(str(level_id))
    except Exception:
        pass
    try:
        b.start_route(str(level_id))
    except Exception:
        pass
    return "ok"

def finish_route(success=True, progress=1.0, reward=1.0):
    b = _ensure()
    try:
        if b.current_episode is not None:
            b.finish_episode(bool(success), float(reward), float(progress))
    except Exception:
        pass
    try:
        if b.current_route is not None:
            b.finish_route(bool(success), float(reward), float(progress))
    except Exception:
        pass
    return "ok"

def portal(portal_type, value=None):
    b = _ensure()
    try:
        if value is None:
            out = b.apply_portal(str(portal_type))
        else:
            out = b.apply_portal(str(portal_type), value)
        return json.dumps(out, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"error": str(e)}, ensure_ascii=False)

def sleep_brain():
    b = _ensure()
    summary = b.sleep(replay_samples=64)
    summary["brain_report"] = b.brain_report()
    return json.dumps(summary, ensure_ascii=False)

def report():
    return json.dumps(_ensure().brain_report(), ensure_ascii=False)

def save_json():
    return json.dumps(_ensure().save_state(), ensure_ascii=False)

def factory_reset():
    global brain
    brain = FlyBrainModel()
    return report()
