"""
fly_brain_model_v12.py

FlyBrain v12
============

Основано на v3 и добавляет:
- Working Memory: кратковременная память последних секунд;
- Visual/Object Memory: память типов препятствий во всей игре;
- Temporal Pattern Memory: последовательности объектов с временными интервалами;
- перенос навыков между уровнями;
- оценку знакомости/опасности объекта;
- jump_score для подключения к платформеру;
- сохранение всей новой памяти.

Это компактная биологически вдохновлённая модель, а не полный мозг Drosophila.
"""

from dataclasses import dataclass
from collections import deque
from typing import Dict, Any, Optional, List, Tuple
import json
import math
import random


def clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, float(x)))


@dataclass
class LIFNeuron:
    tau: float
    base_threshold: float

    v: float = 0.0
    spike: int = 0
    rate: float = 0.0
    adaptation: float = 0.0
    trace: float = 0.0
    last_spike_time: float = -999.0

    @property
    def threshold(self):
        return self.base_threshold + self.adaptation

    def step(self, current: float, dt: float, now: float) -> int:
        current = max(0.0, float(current))

        self.v += dt * ((current - self.v) / self.tau)
        self.adaptation *= math.exp(-dt / 0.50)
        self.trace *= math.exp(-dt / 0.20)

        self.spike = 0

        if self.v >= self.threshold:
            self.spike = 1
            self.v = 0.0
            self.last_spike_time = now
            self.trace = 1.0
            self.adaptation = min(0.30, self.adaptation + 0.035)

        self.rate = self.rate * 0.88 + self.spike * 0.12
        return self.spike

    def reset_activity(self):
        self.v = 0.0
        self.spike = 0
        self.rate = 0.0
        self.adaptation = 0.0
        self.trace = 0.0
        self.last_spike_time = -999.0


@dataclass
class Synapse:
    pre: str
    post: str
    weight: float

    min_weight: float = 0.05
    max_weight: float = 4.00
    eligibility: float = 0.0

    def output(self, neurons: Dict[str, LIFNeuron]) -> float:
        return neurons[self.pre].rate * self.weight

    def decay(self, dt: float):
        self.eligibility *= math.exp(-dt / 0.75)

    def observe_spikes(self, neurons: Dict[str, LIFNeuron]):
        pre = neurons[self.pre]
        post = neurons[self.post]

        if post.spike and pre.last_spike_time > -900:
            delta = post.last_spike_time - pre.last_spike_time
            if 0 <= delta <= 0.08:
                self.eligibility += 0.028 * math.exp(-delta / 0.030)

        if pre.spike and post.last_spike_time > -900:
            delta = post.last_spike_time - pre.last_spike_time
            if -0.08 <= delta < 0:
                self.eligibility -= 0.020 * math.exp(delta / 0.030)

        self.eligibility = max(-1.5, min(1.5, self.eligibility))

    def reinforce(self, dopamine: float, dt: float):
        self.weight += dopamine * self.eligibility * dt * 0.18
        self.weight = max(self.min_weight, min(self.max_weight, self.weight))


class WorkingMemory:
    """
    Хранит недавние сенсорные события.
    События автоматически забываются после horizon секунд.
    """

    def __init__(self, horizon: float = 4.0, max_events: int = 256):
        self.horizon = horizon
        self.events = deque(maxlen=max_events)

    def add(
        self,
        now: float,
        kind: str,
        value: float = 1.0,
        label: Optional[str] = None,
    ):
        self.events.append({
            "time": float(now),
            "kind": str(kind),
            "value": float(value),
            "label": label,
        })
        self.prune(now)

    def prune(self, now: float):
        while self.events and now - self.events[0]["time"] > self.horizon:
            self.events.popleft()

    def recent(self, now: float, seconds: float = 1.0) -> List[Dict[str, Any]]:
        self.prune(now)
        return [
            e for e in self.events
            if now - e["time"] <= seconds
        ]

    def last_labels(self, now: float, count: int = 4) -> List[str]:
        self.prune(now)
        labels = [
            e["label"] for e in self.events
            if e.get("label")
        ]
        return labels[-count:]

    def clear(self):
        self.events.clear()


class FlyBrainModel:
    VERSION = 4

    KNOWN_OBJECTS = {
        "spike", "double_spike", "triple_spike",
        "saw", "portal", "orb", "pad",
        "food", "coin", "block", "door", "key"
    }

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}

        self.memory_food = clamp(saved.get("memory_food", 0.12))
        self.energy = clamp(saved.get("energy", 0.80))
        self.age = max(0.0, float(saved.get("age", 0.0)))
        self.total_spikes = max(0, int(saved.get("total_spikes", 0)))
        self.dopamine = float(saved.get("dopamine", 0.0))

        self.obstacle_memory = saved.get("obstacle_memory", {})
        self.skills = saved.get("skills", {
            "spike": 0.0,
            "saw": 0.0,
            "portal": 0.0,
            "orb": 0.0,
        })

        # v4: память объектов и паттернов.
        self.visual_memory = saved.get("visual_memory", {})
        self.pattern_memory = saved.get("pattern_memory", {})

        # Кратковременная память намеренно НЕ загружается между запусками.
        self.working_memory = WorkingMemory(horizon=4.0, max_events=256)

        self.last_object: Optional[str] = None
        self.last_object_time: float = -999.0

        self.n = {
            "T1": LIFNeuron(.10, .58),
            "T2": LIFNeuron(.11, .56),
            "T4_T5": LIFNeuron(.11, .54),
            "LC4": LIFNeuron(.09, .50),
            "GF": LIFNeuron(.07, .46),

            "ORN": LIFNeuron(.12, .52),
            "PN": LIFNeuron(.13, .50),
            "KC": LIFNeuron(.18, .52),
            "MBON": LIFNeuron(.14, .48),

            # v4: небольшой ассоциативный слой.
            "ASSOC_VISUAL": LIFNeuron(.16, .50),
            "ASSOC_PATTERN": LIFNeuron(.18, .50),

            "DN_FORWARD": LIFNeuron(.12, .48),
            "DN_TURN": LIFNeuron(.12, .50),
            "DN_ESCAPE": LIFNeuron(.07, .44),
            "DN_JUMP": LIFNeuron(.10, .46),
        }

        initial = {
            "T1>T2": ("T1", "T2", 2.80),
            "T2>T4_T5": ("T2", "T4_T5", 2.70),
            "T4_T5>LC4": ("T4_T5", "LC4", 2.80),
            "LC4>GF": ("LC4", "GF", 3.00),

            "ORN>PN": ("ORN", "PN", 3.00),
            "PN>KC": ("PN", "KC", 3.00),
            "KC>MBON": ("KC", "MBON", 3.20),

            # v4 association
            "LC4>ASSOC_VISUAL": ("LC4", "ASSOC_VISUAL", 1.70),
            "ASSOC_VISUAL>ASSOC_PATTERN": ("ASSOC_VISUAL", "ASSOC_PATTERN", 1.60),
            "ASSOC_PATTERN>DN_JUMP": ("ASSOC_PATTERN", "DN_JUMP", 2.10),

            "MBON>DN_FORWARD": ("MBON", "DN_FORWARD", 2.10),
            "GF>DN_ESCAPE": ("GF", "DN_ESCAPE", 2.60),
        }

        saved_weights = saved.get("synapses", {})
        self.synapses: Dict[str, Synapse] = {}

        for key, (pre, post, weight) in initial.items():
            self.synapses[key] = Synapse(
                pre=pre,
                post=post,
                weight=float(saved_weights.get(key, weight)),
            )

    def _syn(self, key: str) -> float:
        return self.synapses[key].output(self.n)

    def _plasticity(self, dt: float):
        for syn in self.synapses.values():
            syn.decay(dt)
            syn.observe_spikes(self.n)
            syn.reinforce(self.dopamine, dt)

        self.dopamine *= math.exp(-dt / 0.45)

    def add_reward(self, value: float):
        value = max(-1.0, min(1.0, float(value)))
        self.dopamine = max(-1.0, min(1.0, self.dopamine + value))

    # ------------------------------------------------------------------
    # v4: VISUAL / OBJECT MEMORY
    # ------------------------------------------------------------------

    def observe_object(
        self,
        object_type: str,
        distance: float,
        danger: float = 0.0,
        value: float = 0.0,
    ):
        """
        Запоминает объект, который видит муха.

        distance: нормализованное расстояние 0..1
                  0 = совсем рядом, 1 = далеко.
        danger:   опасность 0..1
        value:    привлекательность/награда -1..1
        """
        object_type = str(object_type).lower()
        distance = clamp(distance)
        danger = clamp(danger)
        value = max(-1.0, min(1.0, float(value)))

        data = self.visual_memory.setdefault(
            object_type,
            {
                "seen": 0,
                "successes": 0,
                "failures": 0,
                "danger": danger,
                "value": value,
                "preferred_timing": 0.50,
            },
        )

        data["seen"] += 1
        data["danger"] = data["danger"] * 0.95 + danger * 0.05
        data["value"] = data["value"] * 0.95 + value * 0.05

        # Не записываем одно и то же каждый кадр в последовательность.
        if object_type != self.last_object or (self.age - self.last_object_time) > 0.30:
            interval = (
                0.0 if self.last_object is None
                else max(0.0, self.age - self.last_object_time)
            )

            self.working_memory.add(
                self.age,
                "object",
                value=1.0 - distance,
                label=object_type,
            )

            self._learn_pattern_from_recent(interval)

            self.last_object = object_type
            self.last_object_time = self.age

        return data

    def _pattern_key(self, labels: List[str]) -> str:
        return ">".join(labels)

    def _learn_pattern_from_recent(self, latest_interval: float):
        labels = self.working_memory.last_labels(self.age, count=4)

        if len(labels) < 2:
            return

        # Сохраняем последние 2..4 объекта как паттерны.
        for length in range(2, len(labels) + 1):
            seq = labels[-length:]
            key = self._pattern_key(seq)

            p = self.pattern_memory.setdefault(
                key,
                {
                    "seen": 0,
                    "successes": 0,
                    "failures": 0,
                    "value": 0.0,
                    "avg_interval": 0.0,
                },
            )

            p["seen"] += 1

            if latest_interval > 0:
                if p["avg_interval"] == 0:
                    p["avg_interval"] = latest_interval
                else:
                    p["avg_interval"] = (
                        p["avg_interval"] * 0.90
                        + latest_interval * 0.10
                    )

    def object_familiarity(self, object_type: str) -> float:
        d = self.visual_memory.get(str(object_type).lower())
        if not d:
            return 0.0
        return clamp(math.log1p(d["seen"]) / math.log(101))

    def object_success_rate(self, object_type: str) -> float:
        d = self.visual_memory.get(str(object_type).lower())
        if not d:
            return 0.0

        attempts = d["successes"] + d["failures"]
        if attempts == 0:
            return 0.0

        return d["successes"] / attempts

    def learn_object_result(
        self,
        object_type: str,
        success: bool,
        timing: float = 0.5,
        reward: Optional[float] = None,
    ):
        object_type = str(object_type).lower()
        timing = clamp(timing)

        d = self.visual_memory.setdefault(
            object_type,
            {
                "seen": 0,
                "successes": 0,
                "failures": 0,
                "danger": 0.5,
                "value": 0.0,
                "preferred_timing": 0.50,
            },
        )

        if success:
            d["successes"] += 1
            alpha = 0.16
        else:
            d["failures"] += 1
            alpha = 0.06

        d["preferred_timing"] = (
            d["preferred_timing"] * (1.0 - alpha)
            + timing * alpha
        )

        if reward is None:
            reward = 0.25 if success else -0.18

        d["value"] = clamp(
            (d["value"] + 1.0) * 0.5
            + reward * 0.08,
            0.0,
            1.0,
        ) * 2.0 - 1.0

        self.add_reward(reward)

        # Учим активные паттерны.
        labels = self.working_memory.last_labels(self.age, count=4)

        for length in range(2, len(labels) + 1):
            key = self._pattern_key(labels[-length:])
            if key not in self.pattern_memory:
                continue

            p = self.pattern_memory[key]

            if success:
                p["successes"] += 1
            else:
                p["failures"] += 1

            p["value"] = (
                p["value"] * 0.92
                + reward * 0.08
            )

    def pattern_confidence(self) -> float:
        labels = self.working_memory.last_labels(self.age, count=4)

        best = 0.0

        for length in range(2, len(labels) + 1):
            key = self._pattern_key(labels[-length:])
            p = self.pattern_memory.get(key)

            if not p:
                continue

            attempts = p["successes"] + p["failures"]

            if attempts:
                confidence = p["successes"] / attempts
                experience = clamp(attempts / 20.0)
                best = max(best, confidence * experience)

        return best

    def jump_recommendation(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
    ) -> Dict[str, float]:
        """
        Универсальный интерфейс для платформера.

        Возвращает:
        - score: вероятность/желательность прыжка 0..1
        - timing: изученный лучший тайминг 0..1
        - familiarity
        - pattern_confidence
        """
        object_type = str(object_type).lower()
        distance = clamp(distance)
        speed = clamp(speed)

        data = self.visual_memory.get(object_type)

        familiarity = self.object_familiarity(object_type)
        success_rate = self.object_success_rate(object_type)
        pattern = self.pattern_confidence()

        preferred = (
            float(data["preferred_timing"])
            if data
            else 0.50
        )

        danger = (
            float(data["danger"])
            if data
            else (0.8 if "spike" in object_type or object_type == "saw" else 0.3)
        )

        # distance=0 значит объект уже рядом.
        proximity = 1.0 - distance

        # При высокой скорости решение принимается чуть раньше.
        speed_urgency = speed * 0.22

        learned = (
            familiarity * 0.18
            + success_rate * 0.18
            + pattern * 0.16
        )

        score = clamp(
            proximity * 0.62
            + danger * 0.22
            + speed_urgency
            + learned
            - 0.24
        )

        return {
            "score": score,
            "timing": preferred,
            "familiarity": familiarity,
            "success_rate": success_rate,
            "pattern_confidence": pattern,
        }

    def learn_obstacle(
        self,
        obstacle_type: str,
        success: bool,
        timing: float,
    ):
        # Сохраняем совместимость с v3.
        name = str(obstacle_type).lower()

        info = self.obstacle_memory.setdefault(
            name,
            {
                "attempts": 0,
                "successes": 0,
                "best_timing": 0.5,
            },
        )

        info["attempts"] += 1

        if success:
            info["successes"] += 1

        timing = clamp(timing)
        alpha = 0.12 if success else 0.035

        info["best_timing"] = (
            info["best_timing"] * (1.0 - alpha)
            + timing * alpha
        )

        self.skills[name] = (
            info["successes"] / max(1, info["attempts"])
        )

        self.learn_object_result(
            name,
            success,
            timing,
            reward=0.20 if success else -0.12,
        )

    # ------------------------------------------------------------------
    # MAIN BRAIN STEP
    # ------------------------------------------------------------------

    def step(
        self,
        dt=.016,
        food_smell=0.0,
        danger=0.0,
        vision_motion=0.0,
        looming=0.0,
        hunger=.6,
        reward=0.0,
        shock=0.0,
        turn_bias=0.0,

        # v4 optional game signals:
        object_type: Optional[str] = None,
        object_distance: float = 1.0,
        object_danger: float = 0.0,
        object_value: float = 0.0,
        speed: float = 0.5,
    ):
        dt = clamp(dt, .001, .05)
        food_smell = clamp(food_smell)
        danger = clamp(danger)
        vision_motion = clamp(vision_motion)
        looming = clamp(looming)
        hunger = clamp(hunger)
        reward = clamp(reward)
        shock = clamp(shock)
        turn_bias = clamp(turn_bias, -1, 1)
        object_distance = clamp(object_distance)
        object_danger = clamp(object_danger)
        speed = clamp(speed)

        now = self.age
        n = self.n
        spikes = 0

        if object_type:
            self.observe_object(
                object_type,
                object_distance,
                object_danger,
                object_value,
            )

        if reward > 0:
            self.add_reward(reward * 0.30)

        # ---------------- ЗРЕНИЕ ----------------
        spikes += n["T1"].step(vision_motion * 1.45, dt, now)

        spikes += n["T2"].step(
            self._syn("T1>T2") + looming * .75,
            dt,
            now,
        )

        spikes += n["T4_T5"].step(
            self._syn("T2>T4_T5") + looming * 1.25,
            dt,
            now,
        )

        spikes += n["LC4"].step(
            self._syn("T4_T5>LC4") + looming * 1.45,
            dt,
            now,
        )

        spikes += n["GF"].step(
            self._syn("LC4>GF") + shock * 2.4,
            dt,
            now,
        )

        # ---------------- АССОЦИАТИВНЫЙ СЛОЙ ----------------
        pattern_conf = self.pattern_confidence()

        object_familiarity = (
            self.object_familiarity(object_type)
            if object_type else 0.0
        )

        spikes += n["ASSOC_VISUAL"].step(
            self._syn("LC4>ASSOC_VISUAL")
            + object_familiarity * 0.50
            + object_danger * 0.55,
            dt,
            now,
        )

        spikes += n["ASSOC_PATTERN"].step(
            self._syn("ASSOC_VISUAL>ASSOC_PATTERN")
            + pattern_conf * 0.80,
            dt,
            now,
        )

        # ---------------- ЗАПАХ ----------------
        spikes += n["ORN"].step(food_smell * 1.75, dt, now)

        spikes += n["PN"].step(
            self._syn("ORN>PN") + food_smell * .20,
            dt,
            now,
        )

        memory_gain = .75 + self.memory_food * 1.50

        spikes += n["KC"].step(
            self._syn("PN>KC") * memory_gain,
            dt,
            now,
        )

        spikes += n["MBON"].step(
            self._syn("KC>MBON")
            + food_smell * (.30 + self.memory_food * .55)
            + reward * .45
            - danger * .70,
            dt,
            now,
        )

        # ---------------- МОТОРИКА ----------------
        food_drive = clamp(
            food_smell
            * (.30 + .70 * hunger)
            * (.55 + .75 * self.memory_food)
            + self._syn("MBON>DN_FORWARD")
        )

        escape_drive = clamp(
            danger * .95
            + looming * .80
            + shock
            + self._syn("GF>DN_ESCAPE")
        )

        jump_hint = 0.0

        if object_type:
            jump_hint = self.jump_recommendation(
                object_type,
                object_distance,
                speed,
            )["score"]

        spikes += n["DN_JUMP"].step(
            self._syn("ASSOC_PATTERN>DN_JUMP")
            + jump_hint * 1.25,
            dt,
            now,
        )

        spikes += n["DN_FORWARD"].step(
            .24
            + food_drive * 1.15
            + self.energy * .10,
            dt,
            now,
        )

        spikes += n["DN_TURN"].step(
            .18
            + abs(turn_bias) * .95
            + food_drive * .20,
            dt,
            now,
        )

        spikes += n["DN_ESCAPE"].step(
            escape_drive * 1.70,
            dt,
            now,
        )

        learning = reward * food_smell * (
            .025 + n["KC"].rate * .09
        )

        self.memory_food = clamp(
            self.memory_food
            + learning
            - dt * .000002
        )

        self.energy = clamp(
            self.energy
            - dt * .0015
            + reward * .035
            - danger * dt * .01
        )

        self._plasticity(dt)

        self.age += dt
        self.total_spikes += spikes
        self.working_memory.prune(self.age)

        escape = clamp(
            escape_drive * .72
            + n["DN_ESCAPE"].rate * 2.8
        )

        forward = clamp(
            .10
            + food_drive * .72
            + n["DN_FORWARD"].rate * 2.2
            - escape * .25
        )

        jump = clamp(
            jump_hint * 0.72
            + n["DN_JUMP"].rate * 2.2
        )

        if escape > .35:
            state = "escape"
        elif jump > .45:
            state = "prepare_jump"
        elif food_drive > .12:
            state = "approach"
        else:
            state = "explore"

        if escape > .35:
            if abs(turn_bias) < .05:
                turn_bias = random.choice((-1.0, 1.0))
            turn = clamp(turn_bias * 1.8, -1, 1)
        elif state == "approach":
            turn = clamp(turn_bias * .65, -1, 1)
        else:
            turn = clamp(turn_bias, -1, 1)

        return {
            "version": self.VERSION,
            "state": state,
            "movement": {
                "forward": forward,
                "turn": turn,
                "escape": escape,
                "jump": jump,
            },
            "memory": {
                "food": self.memory_food,
                "energy": self.energy,
                "age": self.age,
                "obstacles": self.obstacle_memory,
                "skills": self.skills,
                "visual_objects": len(self.visual_memory),
                "patterns": len(self.pattern_memory),
                "working_events": len(self.working_memory.events),
            },
            "recognition": {
                "object": object_type,
                "familiarity": object_familiarity,
                "pattern_confidence": pattern_conf,
                "jump_score": jump_hint,
            },
            "learning": {
                "dopamine": self.dopamine,
                "synapses": {
                    key: syn.weight
                    for key, syn in self.synapses.items()
                },
            },
            "neurons": {
                name: {
                    "v": neuron.v,
                    "spike": neuron.spike,
                    "rate": neuron.rate,
                    "threshold": neuron.threshold,
                    "adaptation": neuron.adaptation,
                    "trace": neuron.trace,
                }
                for name, neuron in n.items()
            },
            "spikes": spikes,
            "total_spikes": self.total_spikes,
        }

    def reward_food(self, smell=1.0, strength=1.0):
        smell = clamp(smell)
        strength = clamp(strength)

        self.memory_food = clamp(
            self.memory_food + smell * strength * .06
        )

        self.energy = clamp(
            self.energy + strength * .08
        )

        self.add_reward(0.35 * smell * strength)

    def punish(self, strength=1.0):
        self.add_reward(-0.35 * clamp(strength))

    def save_state(self):
        return {
            "version": self.VERSION,
            "memory_food": self.memory_food,
            "energy": self.energy,
            "age": self.age,
            "total_spikes": self.total_spikes,
            "dopamine": self.dopamine,
            "obstacle_memory": self.obstacle_memory,
            "skills": self.skills,
            "visual_memory": self.visual_memory,
            "pattern_memory": self.pattern_memory,
            "synapses": {
                key: syn.weight
                for key, syn in self.synapses.items()
            },
        }

    def save_to_file(self, path="fly_brain_memory_v4.json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(cls, path="fly_brain_memory_v4.json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()

    def reset_activity(self):
        for neuron in self.n.values():
            neuron.reset_activity()

        self.dopamine = 0.0
        self.working_memory.clear()
        self.last_object = None
        self.last_object_time = -999.0

    def factory_reset(self):
        fresh = FlyBrainModel()
        self.__dict__.clear()
        self.__dict__.update(fresh.__dict__)



# ======================================================================
# FLY BRAIN V5
# Эпизодическая память + прогноз следующего события
# ======================================================================

BaseFlyBrainModel = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModel):
    VERSION = 5

    MAX_EPISODES = 200

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # Долговременная память целых попыток/участков.
        self.episode_memory = list(saved.get("episode_memory", []))[-self.MAX_EPISODES:]

        # Вероятностная память переходов:
        # "spike" -> {"portal": 15, "orb": 2, ...}
        self.transition_memory = dict(saved.get("transition_memory", {}))

        # Текущий эпизод намеренно не сохраняется.
        self.current_episode = None

    # ------------------------------------------------------------------
    # EPISODIC MEMORY
    # ------------------------------------------------------------------

    def start_episode(self, level_id: str = ""):
        """
        Вызывать в начале попытки или перед сложным участком уровня.
        """
        self.current_episode = {
            "level_id": str(level_id),
            "started_at": self.age,
            "events": [],
        }

    def _record_episode_event(
        self,
        object_type: Optional[str],
        distance: float,
        danger: float,
        output: Dict[str, Any],
    ):
        if self.current_episode is None or not object_type:
            return

        events = self.current_episode["events"]

        # Не забиваем память одинаковым объектом на каждом кадре.
        if events:
            last = events[-1]
            if (
                last["object"] == object_type
                and self.age - last["time"] < 0.30
            ):
                # Но обновим минимальное расстояние и максимальную опасность.
                last["distance"] = min(last["distance"], float(distance))
                last["danger"] = max(last["danger"], float(danger))
                last["jump"] = max(
                    last["jump"],
                    float(output["movement"].get("jump", 0.0)),
                )
                return

        events.append({
            "time": float(self.age),
            "object": str(object_type),
            "distance": clamp(distance),
            "danger": clamp(danger),
            "jump": clamp(output["movement"].get("jump", 0.0)),
            "escape": clamp(output["movement"].get("escape", 0.0)),
            "state": str(output.get("state", "explore")),
        })

        # Ограничиваем длину одной попытки.
        if len(events) > 128:
            del events[:-128]

    def finish_episode(
        self,
        success: bool,
        reward: float = 0.0,
        progress: float = 1.0,
    ):
        """
        Завершает попытку и переносит её в долговременную память.
        """
        if self.current_episode is None:
            return None

        events = self.current_episode["events"]

        if not events:
            self.current_episode = None
            return None

        reward = max(-1.0, min(1.0, float(reward)))
        progress = clamp(progress)

        episode = {
            "level_id": self.current_episode.get("level_id", ""),
            "success": bool(success),
            "reward": reward,
            "progress": progress,
            "duration": max(
                0.0,
                self.age - self.current_episode["started_at"],
            ),
            "events": events,
        }

        self.episode_memory.append(episode)

        if len(self.episode_memory) > self.MAX_EPISODES:
            self.episode_memory = self.episode_memory[-self.MAX_EPISODES:]

        # Итог попытки тоже влияет на пластичность.
        if success:
            self.add_reward(0.30 + max(0.0, reward) * 0.25)
        else:
            self.add_reward(-0.18 * (1.0 - progress * 0.40))

        self.current_episode = None
        return episode

    # ------------------------------------------------------------------
    # TRANSITION / PREDICTION MEMORY
    # ------------------------------------------------------------------

    def _remember_transition(self, previous: str, current: str):
        if not previous or not current or previous == current:
            return

        row = self.transition_memory.setdefault(previous, {})
        row[current] = int(row.get(current, 0)) + 1

    def observe_object(
        self,
        object_type: str,
        distance: float,
        danger: float = 0.0,
        value: float = 0.0,
    ):
        obj = str(object_type).lower()

        previous = self.last_object
        should_transition = (
            previous is not None
            and obj != previous
        )

        data = super().observe_object(
            obj,
            distance,
            danger,
            value,
        )

        if should_transition:
            self._remember_transition(previous, obj)

        return data

    def predict_next_object(
        self,
        current_object: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Возвращает наиболее вероятный следующий объект.
        """
        current_object = (
            str(current_object).lower()
            if current_object
            else self.last_object
        )

        if not current_object:
            return {
                "object": None,
                "probability": 0.0,
                "alternatives": {},
            }

        row = self.transition_memory.get(current_object, {})

        if not row:
            return {
                "object": None,
                "probability": 0.0,
                "alternatives": {},
            }

        total = sum(max(0, int(v)) for v in row.values())

        if total <= 0:
            return {
                "object": None,
                "probability": 0.0,
                "alternatives": {},
            }

        probabilities = {
            key: value / total
            for key, value in row.items()
        }

        best = max(probabilities, key=probabilities.get)

        return {
            "object": best,
            "probability": probabilities[best],
            "alternatives": probabilities,
        }

    # ------------------------------------------------------------------
    # EPISODIC RETRIEVAL
    # ------------------------------------------------------------------

    def _current_object_sequence(self, count: int = 4) -> List[str]:
        return self.working_memory.last_labels(self.age, count=count)

    @staticmethod
    def _find_sequence(sequence: List[str], query: List[str]):
        """
        Возвращает индекс конца query внутри sequence.
        Берём последнее совпадение.
        """
        if not query or len(query) > len(sequence):
            return None

        found = None

        for start in range(0, len(sequence) - len(query) + 1):
            if sequence[start:start + len(query)] == query:
                found = start + len(query) - 1

        return found

    def recall_episode(self) -> Dict[str, Any]:
        """
        Ищет наиболее похожий успешный эпизод по недавней
        последовательности объектов.
        """
        recent = self._current_object_sequence(count=4)

        if not recent:
            return {
                "found": False,
                "confidence": 0.0,
                "jump": 0.0,
                "episode": None,
            }

        best = None
        best_score = 0.0
        best_jump = 0.0

        # Пытаемся совпасть сначала по длинной последовательности,
        # затем по более короткой.
        queries = [
            recent[-length:]
            for length in range(min(4, len(recent)), 0, -1)
        ]

        for episode in reversed(self.episode_memory):
            if not episode.get("success", False):
                continue

            events = episode.get("events", [])
            objects = [e.get("object") for e in events]

            for query in queries:
                idx = self._find_sequence(objects, query)

                if idx is None:
                    continue

                similarity = len(query) / max(1, len(recent))
                progress = clamp(episode.get("progress", 1.0))
                reward = max(
                    -1.0,
                    min(1.0, float(episode.get("reward", 0.0))),
                )

                # Успешные далеко пройденные эпизоды ценнее.
                score = (
                    similarity * 0.70
                    + progress * 0.20
                    + max(0.0, reward) * 0.10
                )

                event = events[idx]
                jump = clamp(event.get("jump", 0.0))

                if score > best_score:
                    best_score = score
                    best = episode
                    best_jump = jump

                break

        return {
            "found": best is not None,
            "confidence": clamp(best_score),
            "jump": best_jump,
            "episode": best,
        }

    # ------------------------------------------------------------------
    # DECISION IMPROVEMENTS
    # ------------------------------------------------------------------

    def jump_recommendation(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
    ) -> Dict[str, float]:
        base = super().jump_recommendation(
            object_type,
            distance,
            speed,
        )

        recall = self.recall_episode()
        prediction = self.predict_next_object(object_type)

        # Если успешный похожий эпизод раньше уже требовал прыжка,
        # используем его как дополнительный, но не абсолютный, совет.
        episodic_bonus = (
            recall["jump"]
            * recall["confidence"]
            * 0.22
            if recall["found"]
            else 0.0
        )

        # Если после текущего препятствия часто идёт ещё одна опасность,
        # немного повышаем готовность заранее.
        predicted_obj = prediction.get("object")
        future_danger = 0.0

        if predicted_obj:
            d = self.visual_memory.get(predicted_obj)
            if d:
                future_danger = clamp(d.get("danger", 0.0))

        prediction_bonus = (
            prediction.get("probability", 0.0)
            * future_danger
            * 0.10
        )

        base["score"] = clamp(
            base["score"]
            + episodic_bonus
            + prediction_bonus
        )

        base["episodic_confidence"] = recall["confidence"]
        base["episodic_jump"] = recall["jump"]
        base["predicted_next_probability"] = prediction.get(
            "probability",
            0.0,
        )

        return base

    def step(self, *args, **kwargs):
        """
        Сохраняет API v4 и автоматически записывает текущий эпизод.
        """
        object_type = kwargs.get("object_type")
        object_distance = kwargs.get("object_distance", 1.0)
        object_danger = kwargs.get("object_danger", 0.0)

        out = super().step(*args, **kwargs)

        self._record_episode_event(
            object_type,
            object_distance,
            object_danger,
            out,
        )

        prediction = self.predict_next_object(object_type)

        out["memory"]["episodes"] = len(self.episode_memory)
        out["memory"]["transitions"] = sum(
            len(v)
            for v in self.transition_memory.values()
        )

        out["prediction"] = prediction

        recall = self.recall_episode()

        out["episodic"] = {
            "found": recall["found"],
            "confidence": recall["confidence"],
            "jump": recall["jump"],
        }

        return out

    # ------------------------------------------------------------------
    # SAVE / RESET
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()
        state.update({
            "version": self.VERSION,
            "episode_memory": self.episode_memory[-self.MAX_EPISODES:],
            "transition_memory": self.transition_memory,
        })
        return state

    def save_to_file(self, path="fly_brain_memory_v5.json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(cls, path="fly_brain_memory_v5.json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()

    def reset_activity(self):
        super().reset_activity()
        self.current_episode = None



# ======================================================================
# FLY BRAIN V6
# Короткое планирование + игровой API
# ======================================================================

BaseFlyBrainModelV5 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV5):
    VERSION = 6

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # Память ценности действий по типам объектов.
        self.action_values = saved.get("action_values", {})

        # Последний построенный план.
        self.last_plan = []

        # Сколько будущих событий пробуем предсказать.
        self.plan_horizon = int(saved.get("plan_horizon", 3))

    # ------------------------------------------------------------------
    # ACTION VALUE MEMORY
    # ------------------------------------------------------------------

    def _action_bucket(self, object_type: str) -> Dict[str, float]:
        object_type = str(object_type).lower()

        return self.action_values.setdefault(
            object_type,
            {
                "jump": 0.0,
                "wait": 0.0,
                "escape": 0.0,
            },
        )

    def learn_action_value(
        self,
        object_type: str,
        action: str,
        reward: float,
        alpha: float = 0.12,
    ):
        """
        Простая долговременная ценность действий.
        """
        action = str(action).lower()

        if action not in ("jump", "wait", "escape"):
            return

        reward = max(-1.0, min(1.0, float(reward)))
        alpha = clamp(alpha, 0.001, 1.0)

        bucket = self._action_bucket(object_type)
        old = float(bucket[action])

        bucket[action] = (
            old * (1.0 - alpha)
            + reward * alpha
        )

        self.add_reward(reward * 0.20)

    # ------------------------------------------------------------------
    # MULTI-STEP PREDICTION
    # ------------------------------------------------------------------

    def _transition_probabilities(self, current: str):
        row = self.transition_memory.get(str(current).lower(), {})

        total = sum(max(0, int(v)) for v in row.values())

        if total <= 0:
            return {}

        return {
            obj: count / total
            for obj, count in row.items()
        }

    def predict_sequence(
        self,
        start_object: str,
        steps: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        Строит наиболее вероятную цепочку будущих объектов.
        """
        steps = (
            self.plan_horizon
            if steps is None
            else max(1, min(6, int(steps)))
        )

        current = str(start_object).lower()
        result = []

        cumulative = 1.0

        for _ in range(steps):
            probs = self._transition_probabilities(current)

            if not probs:
                break

            nxt = max(probs, key=probs.get)
            p = probs[nxt]

            cumulative *= p

            result.append({
                "from": current,
                "object": nxt,
                "probability": p,
                "cumulative_probability": cumulative,
            })

            current = nxt

        return result

    # ------------------------------------------------------------------
    # PLANNER
    # ------------------------------------------------------------------

    def _danger_of(self, object_type: Optional[str]) -> float:
        if not object_type:
            return 0.0

        data = self.visual_memory.get(str(object_type).lower())

        if data:
            return clamp(data.get("danger", 0.0))

        name = str(object_type).lower()

        if "spike" in name or name in ("saw", "laser"):
            return 0.9

        if name in ("portal", "orb", "pad"):
            return 0.25

        return 0.1

    def _value_of(self, object_type: Optional[str]) -> float:
        if not object_type:
            return 0.0

        data = self.visual_memory.get(str(object_type).lower())

        if not data:
            return 0.0

        return max(-1.0, min(1.0, float(data.get("value", 0.0))))

    def build_plan(
        self,
        object_type: str,
        distance: float,
        speed: float,
    ) -> List[Dict[str, Any]]:
        """
        Короткий план на текущий объект и несколько ожидаемых следующих.
        """
        object_type = str(object_type).lower()
        distance = clamp(distance)
        speed = clamp(speed)

        current_rec = self.jump_recommendation(
            object_type,
            distance,
            speed,
        )

        plan = []

        # Текущий шаг.
        if current_rec["score"] >= 0.58:
            current_action = "jump"
        elif self._danger_of(object_type) >= 0.85 and distance < 0.18:
            current_action = "escape"
        else:
            current_action = "wait"

        plan.append({
            "step": 0,
            "object": object_type,
            "action": current_action,
            "confidence": clamp(
                max(
                    current_rec["score"],
                    current_rec.get("familiarity", 0.0) * 0.5,
                )
            ),
        })

        future = self.predict_sequence(
            object_type,
            self.plan_horizon,
        )

        for idx, item in enumerate(future, start=1):
            obj = item["object"]
            danger = self._danger_of(obj)
            value = self._value_of(obj)
            p = item["cumulative_probability"]

            bucket = self._action_bucket(obj)

            jump_bias = (
                danger * 0.55
                + max(0.0, bucket["jump"]) * 0.25
                + max(0.0, value) * 0.05
            )

            escape_bias = (
                danger * 0.70
                + max(0.0, bucket["escape"]) * 0.20
            )

            if obj in ("portal", "orb", "pad"):
                # Тут чаще важнее подготовиться, чем прыгать сразу.
                action = "prepare"
                confidence = clamp(p * (0.55 + danger * 0.25))
            elif escape_bias > 0.82:
                action = "escape"
                confidence = clamp(p * escape_bias)
            elif jump_bias > 0.50:
                action = "jump"
                confidence = clamp(p * jump_bias)
            else:
                action = "wait"
                confidence = clamp(p * (0.45 + max(0.0, value) * 0.20))

            plan.append({
                "step": idx,
                "object": obj,
                "action": action,
                "confidence": confidence,
                "probability": p,
            })

        self.last_plan = plan
        return plan

    # ------------------------------------------------------------------
    # GAME API
    # ------------------------------------------------------------------

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,
    ) -> Dict[str, Any]:
        """
        Удобный API для Fly Dash / платформера.

        distance:
            0.0 = препятствие вплотную
            1.0 = далеко.

        Возвращает:
            action: jump / wait / escape
            jump: bool
            confidence: 0..1
            plan: прогноз следующих шагов
            brain: полный выход step()
        """
        object_type = str(object_type).lower()
        distance = clamp(distance)
        speed = clamp(speed)

        if danger is None:
            danger = self._danger_of(object_type)

        danger = clamp(danger)

        out = self.step(
            dt=dt,
            danger=danger * max(0.0, 1.0 - distance),
            vision_motion=vision_motion,
            looming=looming,
            object_type=object_type,
            object_distance=distance,
            object_danger=danger,
            speed=speed,
        )

        plan = self.build_plan(
            object_type,
            distance,
            speed,
        )

        first = plan[0]

        # Используем и planner, и DN_JUMP.
        neural_jump = out["movement"]["jump"]
        planner_jump = 1.0 if first["action"] == "jump" else 0.0

        combined_jump = clamp(
            neural_jump * 0.72
            + planner_jump * first["confidence"] * 0.28
        )

        if out["movement"]["escape"] > 0.65:
            action = "escape"
        elif combined_jump > 0.55:
            action = "jump"
        else:
            action = "wait"

        return {
            "action": action,
            "jump": action == "jump",
            "escape": action == "escape",
            "confidence": max(
                first["confidence"],
                combined_jump if action == "jump" else 0.0,
            ),
            "jump_score": combined_jump,
            "plan": plan,
            "brain": out,
        }

    def learn_game_result(
        self,
        object_type: str,
        action: str,
        success: bool,
        timing: float = 0.5,
        progress: float = 0.0,
    ):
        """
        Сообщить мозгу результат игрового действия.
        """
        progress = clamp(progress)

        if success:
            reward = 0.35 + progress * 0.35
        else:
            reward = -0.45 + progress * 0.20

        self.learn_object_result(
            object_type,
            success=success,
            timing=timing,
            reward=reward,
        )

        self.learn_action_value(
            object_type,
            action,
            reward,
        )

    # ------------------------------------------------------------------
    # MEMORY CONSOLIDATION
    # ------------------------------------------------------------------

    def consolidate_memory(self):
        """
        Компактная "консолидация":
        - старые слабые эпизоды удаляем;
        - сильные успешные оставляем;
        - очень редкие паттерны с нулевой ценностью забываем.
        """
        if self.episode_memory:
            ranked = sorted(
                self.episode_memory,
                key=lambda ep: (
                    bool(ep.get("success", False)),
                    float(ep.get("progress", 0.0)),
                    float(ep.get("reward", 0.0)),
                ),
                reverse=True,
            )

            # Сохраняем лучшие + немного недавних.
            best = ranked[:140]
            recent = self.episode_memory[-40:]

            unique = []
            seen_ids = set()

            for ep in best + recent:
                marker = id(ep)
                if marker in seen_ids:
                    continue
                seen_ids.add(marker)
                unique.append(ep)

            self.episode_memory = unique[-self.MAX_EPISODES:]

        weak_patterns = []

        for key, data in self.pattern_memory.items():
            seen = int(data.get("seen", 0))
            value = abs(float(data.get("value", 0.0)))
            attempts = int(data.get("successes", 0)) + int(data.get("failures", 0))

            if seen <= 1 and attempts == 0 and value < 0.02:
                weak_patterns.append(key)

        for key in weak_patterns[:100]:
            self.pattern_memory.pop(key, None)

        return {
            "episodes": len(self.episode_memory),
            "patterns": len(self.pattern_memory),
            "removed_weak_patterns": len(weak_patterns[:100]),
        }

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "action_values": self.action_values,
            "plan_horizon": self.plan_horizon,
        })

        return state

    def save_to_file(self, path="fly_brain_memory_v6.json"):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(cls, path="fly_brain_memory_v6.json"):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V7
# Ритм-память + музыкальная синхронизация
# ======================================================================

BaseFlyBrainModelV6 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV6):
    VERSION = 7

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # music_id -> object_type -> learned rhythm data
        self.rhythm_memory = saved.get("rhythm_memory", {})

        # Текущее состояние музыки.
        self.current_music_id = None
        self.current_bpm = 120.0
        self.current_beat_phase = 0.0
        self.current_beat_strength = 0.0

    # ------------------------------------------------------------------
    # RHYTHM MEMORY
    # ------------------------------------------------------------------

    @staticmethod
    def _circular_phase_distance(a: float, b: float) -> float:
        """
        Фаза 0..1 циклична.
        0.98 и 0.02 близки друг к другу.
        """
        a = clamp(a)
        b = clamp(b)
        d = abs(a - b)
        return min(d, 1.0 - d)

    def observe_rhythm(
        self,
        music_id: str,
        bpm: float,
        beat_phase: float,
        beat_strength: float = 1.0,
    ):
        self.current_music_id = str(music_id)
        self.current_bpm = max(30.0, min(300.0, float(bpm)))
        self.current_beat_phase = clamp(beat_phase)
        self.current_beat_strength = clamp(beat_strength)

        self.working_memory.add(
            self.age,
            "beat",
            value=self.current_beat_strength,
            label=None,
        )

    def _rhythm_bucket(
        self,
        music_id: str,
        object_type: str,
    ) -> Dict[str, Any]:
        music_id = str(music_id)
        object_type = str(object_type).lower()

        music = self.rhythm_memory.setdefault(music_id, {})

        return music.setdefault(
            object_type,
            {
                "attempts": 0,
                "successes": 0,
                "preferred_phase": 0.50,
                "phase_confidence": 0.0,
                "avg_strength": 0.0,
            },
        )

    def learn_rhythm_result(
        self,
        music_id: str,
        object_type: str,
        beat_phase: float,
        success: bool,
        beat_strength: float = 1.0,
    ):
        """
        Запоминает фазу бита, на которой действие было успешным.
        """
        beat_phase = clamp(beat_phase)
        beat_strength = clamp(beat_strength)

        data = self._rhythm_bucket(
            music_id,
            object_type,
        )

        data["attempts"] += 1

        if success:
            data["successes"] += 1

            # Для циклической фазы делаем плавный шаг
            # в кратчайшую сторону.
            old = float(data["preferred_phase"])
            delta = beat_phase - old

            if delta > 0.5:
                delta -= 1.0
            elif delta < -0.5:
                delta += 1.0

            alpha = 0.18 + beat_strength * 0.10

            data["preferred_phase"] = (
                old + delta * alpha
            ) % 1.0

        data["avg_strength"] = (
            float(data["avg_strength"]) * 0.90
            + beat_strength * 0.10
        )

        attempts = max(1, int(data["attempts"]))
        success_rate = int(data["successes"]) / attempts

        experience = clamp(attempts / 20.0)

        data["phase_confidence"] = (
            success_rate * experience
        )

        self.add_reward(
            0.16 if success else -0.08
        )

    def rhythm_recommendation(
        self,
        music_id: str,
        object_type: str,
        beat_phase: float,
        beat_strength: float = 1.0,
    ) -> Dict[str, float]:
        beat_phase = clamp(beat_phase)
        beat_strength = clamp(beat_strength)

        music = self.rhythm_memory.get(
            str(music_id),
            {},
        )

        data = music.get(
            str(object_type).lower()
        )

        if not data:
            return {
                "known": 0.0,
                "preferred_phase": 0.5,
                "phase_match": 0.0,
                "confidence": 0.0,
                "bonus": 0.0,
            }

        preferred = clamp(data["preferred_phase"])
        distance = self._circular_phase_distance(
            beat_phase,
            preferred,
        )

        # 0.0 distance -> perfect match
        # 0.5 -> opposite beat phase
        phase_match = clamp(
            1.0 - distance / 0.5
        )

        confidence = clamp(
            data.get("phase_confidence", 0.0)
        )

        bonus = (
            phase_match
            * confidence
            * (0.55 + beat_strength * 0.45)
            * 0.22
        )

        return {
            "known": 1.0,
            "preferred_phase": preferred,
            "phase_match": phase_match,
            "confidence": confidence,
            "bonus": bonus,
        }

    # ------------------------------------------------------------------
    # MUSIC-AWARE PLANNING
    # ------------------------------------------------------------------

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        # v7:
        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,
    ) -> Dict[str, Any]:

        object_type = str(object_type).lower()
        distance = clamp(distance)
        speed = clamp(speed)

        if music_id is not None:
            self.observe_rhythm(
                music_id,
                bpm,
                beat_phase,
                beat_strength,
            )

        # Получаем решение v6.
        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
        )

        rhythm = {
            "known": 0.0,
            "preferred_phase": 0.5,
            "phase_match": 0.0,
            "confidence": 0.0,
            "bonus": 0.0,
        }

        if music_id is not None:
            rhythm = self.rhythm_recommendation(
                music_id,
                object_type,
                beat_phase,
                beat_strength,
            )

        combined_jump = clamp(
            base["jump_score"]
            + rhythm["bonus"]
        )

        # Ритм может подтолкнуть к прыжку,
        # но не отменяет критический escape.
        if base["escape"]:
            action = "escape"
        elif combined_jump > 0.55:
            action = "jump"
        else:
            action = "wait"

        base["action"] = action
        base["jump"] = action == "jump"
        base["escape"] = action == "escape"
        base["jump_score"] = combined_jump
        base["confidence"] = max(
            base["confidence"],
            combined_jump if action == "jump" else 0.0,
        )

        base["rhythm"] = rhythm

        return base

    def learn_game_result(
        self,
        object_type: str,
        action: str,
        success: bool,
        timing: float = 0.5,
        progress: float = 0.0,

        # v7:
        music_id: Optional[str] = None,
        beat_phase: Optional[float] = None,
        beat_strength: float = 1.0,
    ):
        super().learn_game_result(
            object_type=object_type,
            action=action,
            success=success,
            timing=timing,
            progress=progress,
        )

        if (
            music_id is not None
            and beat_phase is not None
        ):
            self.learn_rhythm_result(
                music_id=music_id,
                object_type=object_type,
                beat_phase=beat_phase,
                success=success,
                beat_strength=beat_strength,
            )

    # ------------------------------------------------------------------
    # BEAT UTILS
    # ------------------------------------------------------------------

    @staticmethod
    def beat_phase_from_time(
        song_time_seconds: float,
        bpm: float,
        offset_seconds: float = 0.0,
    ) -> float:
        """
        Вычисляет фазу бита 0..1 из времени трека.
        """
        bpm = max(1.0, float(bpm))

        beat_length = 60.0 / bpm

        local = (
            float(song_time_seconds)
            - float(offset_seconds)
        )

        return (local % beat_length) / beat_length

    @staticmethod
    def beat_index_from_time(
        song_time_seconds: float,
        bpm: float,
        offset_seconds: float = 0.0,
    ) -> int:
        bpm = max(1.0, float(bpm))
        beat_length = 60.0 / bpm

        local = (
            float(song_time_seconds)
            - float(offset_seconds)
        )

        return math.floor(local / beat_length)

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "rhythm_memory": self.rhythm_memory,
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v7.json",
    ):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v7.json",
    ):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V8
# Игровые режимы + гравитация + скорость + порталы
# ======================================================================

BaseFlyBrainModelV7 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV7):
    VERSION = 8

    VALID_MODES = (
        "cube",
        "fly",
        "ship",
        "ufo",
        "wave",
    )

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # Текущий игровой контекст.
        self.game_mode = str(
            saved.get("game_mode", "fly")
        ).lower()

        if self.game_mode not in self.VALID_MODES:
            self.game_mode = "fly"

        # 1.0 = обычная гравитация, -1.0 = перевёрнутая.
        self.gravity = float(
            saved.get("gravity", 1.0)
        )

        self.gravity = 1.0 if self.gravity >= 0 else -1.0

        # Множитель скорости уровня.
        self.speed_multiplier = max(
            0.25,
            min(4.0, float(
                saved.get("speed_multiplier", 1.0)
            )),
        )

        # Отдельная память навыков:
        # mode -> object -> stats
        self.mode_skill_memory = saved.get(
            "mode_skill_memory",
            {},
        )

        # История порталов нужна, чтобы мозг учитывал
        # резкие изменения контекста.
        self.portal_memory = saved.get(
            "portal_memory",
            [],
        )[-128:]

    # ------------------------------------------------------------------
    # CONTEXT
    # ------------------------------------------------------------------

    def set_game_context(
        self,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ):
        if game_mode is not None:
            mode = str(game_mode).lower()

            if mode not in self.VALID_MODES:
                raise ValueError(
                    f"Unknown game mode: {mode}"
                )

            self.game_mode = mode

        if gravity is not None:
            self.gravity = (
                1.0
                if float(gravity) >= 0
                else -1.0
            )

        if speed_multiplier is not None:
            self.speed_multiplier = max(
                0.25,
                min(4.0, float(speed_multiplier)),
            )

    def context_key(
        self,
        object_type: str,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> str:
        mode = (
            self.game_mode
            if game_mode is None
            else str(game_mode).lower()
        )

        grav = (
            self.gravity
            if gravity is None
            else (1.0 if float(gravity) >= 0 else -1.0)
        )

        speed = (
            self.speed_multiplier
            if speed_multiplier is None
            else float(speed_multiplier)
        )

        # Скорость округляем по "корзинам", чтобы память
        # не распадалась на тысячи почти одинаковых ключей.
        speed_bucket = round(speed * 2.0) / 2.0

        return (
            f"{mode}|g={int(grav)}|"
            f"s={speed_bucket:.1f}|"
            f"{str(object_type).lower()}"
        )

    # ------------------------------------------------------------------
    # MODE-SPECIFIC SKILLS
    # ------------------------------------------------------------------

    def _mode_bucket(
        self,
        game_mode: str,
        object_type: str,
    ) -> Dict[str, Any]:
        game_mode = str(game_mode).lower()
        object_type = str(object_type).lower()

        mode_data = self.mode_skill_memory.setdefault(
            game_mode,
            {},
        )

        return mode_data.setdefault(
            object_type,
            {
                "attempts": 0,
                "successes": 0,
                "failures": 0,
                "confidence": 0.0,
                "preferred_control": 0.5,
            },
        )

    def learn_mode_skill(
        self,
        game_mode: str,
        object_type: str,
        success: bool,
        control_strength: float = 0.5,
    ):
        bucket = self._mode_bucket(
            game_mode,
            object_type,
        )

        bucket["attempts"] += 1

        if success:
            bucket["successes"] += 1
        else:
            bucket["failures"] += 1

        control_strength = clamp(control_strength)

        alpha = 0.18 if success else 0.05

        bucket["preferred_control"] = (
            float(bucket["preferred_control"])
            * (1.0 - alpha)
            + control_strength * alpha
        )

        attempts = max(
            1,
            int(bucket["attempts"]),
        )

        success_rate = (
            int(bucket["successes"])
            / attempts
        )

        experience = clamp(
            attempts / 20.0
        )

        bucket["confidence"] = (
            success_rate * experience
        )

        return bucket

    def mode_skill(
        self,
        game_mode: str,
        object_type: str,
    ) -> Dict[str, float]:
        bucket = self._mode_bucket(
            game_mode,
            object_type,
        )

        attempts = max(
            1,
            int(bucket["attempts"]),
        )

        return {
            "success_rate": (
                int(bucket["successes"])
                / attempts
            ),
            "confidence": clamp(
                bucket["confidence"]
            ),
            "preferred_control": clamp(
                bucket["preferred_control"]
            ),
        }

    # ------------------------------------------------------------------
    # PORTALS
    # ------------------------------------------------------------------

    def apply_portal(
        self,
        portal_type: str,
        value: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Поддерживаем несколько типов порталов:
        - gravity_flip
        - gravity_normal
        - speed
        - mode
        """
        portal_type = str(portal_type).lower()

        before = {
            "mode": self.game_mode,
            "gravity": self.gravity,
            "speed_multiplier": self.speed_multiplier,
        }

        if portal_type == "gravity_flip":
            self.gravity *= -1.0

        elif portal_type == "gravity_normal":
            self.gravity = 1.0

        elif portal_type == "speed":
            if value is None:
                value = 1.0

            self.speed_multiplier = max(
                0.25,
                min(4.0, float(value)),
            )

        elif portal_type == "mode":
            mode = str(value).lower()

            if mode not in self.VALID_MODES:
                raise ValueError(
                    f"Unknown portal mode: {mode}"
                )

            self.game_mode = mode

        else:
            raise ValueError(
                f"Unknown portal type: {portal_type}"
            )

        event = {
            "time": self.age,
            "portal_type": portal_type,
            "before": before,
            "after": {
                "mode": self.game_mode,
                "gravity": self.gravity,
                "speed_multiplier": self.speed_multiplier,
            },
        }

        self.portal_memory.append(event)

        if len(self.portal_memory) > 128:
            self.portal_memory = self.portal_memory[-128:]

        self.working_memory.add(
            self.age,
            "portal",
            value=1.0,
            label=f"portal:{portal_type}",
        )

        return event

    # ------------------------------------------------------------------
    # MODE CONTROL
    # ------------------------------------------------------------------

    def _mode_control_from_score(
        self,
        mode: str,
        score: float,
        danger: float,
        gravity: float,
    ) -> Dict[str, Any]:
        """
        Перевод общего решения мозга в управление
        конкретным игровым режимом.
        """
        mode = str(mode).lower()
        score = clamp(score)
        danger = clamp(danger)

        gravity_sign = 1.0 if gravity >= 0 else -1.0

        if mode == "cube":
            return {
                "action": "jump" if score > 0.55 else "wait",
                "jump": score > 0.55,
                "hold": False,
                "vertical": 0.0,
            }

        if mode == "fly":
            # "fly" можно удерживать мягко,
            # а не только делать одиночный прыжок.
            strength = clamp(
                score * 0.85
                + danger * 0.15
            )

            return {
                "action": "flap" if strength > 0.45 else "glide",
                "jump": False,
                "hold": strength > 0.45,
                "vertical": gravity_sign * strength,
            }

        if mode == "ship":
            strength = clamp(
                score * 0.78
                + danger * 0.18
            )

            return {
                "action": "thrust" if strength > 0.48 else "coast",
                "jump": False,
                "hold": strength > 0.48,
                "vertical": gravity_sign * strength,
            }

        if mode == "ufo":
            return {
                "action": "flap" if score > 0.52 else "wait",
                "jump": score > 0.52,
                "hold": False,
                "vertical": 0.0,
            }

        if mode == "wave":
            direction = (
                gravity_sign
                if score > 0.50
                else -gravity_sign
            )

            return {
                "action": "wave_up" if direction > 0 else "wave_down",
                "jump": False,
                "hold": direction > 0,
                "vertical": direction,
            }

        return {
            "action": "wait",
            "jump": False,
            "hold": False,
            "vertical": 0.0,
        }

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,

        # v8
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:

        if game_mode is not None or gravity is not None or speed_multiplier is not None:
            self.set_game_context(
                game_mode=game_mode,
                gravity=gravity,
                speed_multiplier=speed_multiplier,
            )

        # Реальная скорость объекта учитывает скорость уровня.
        effective_speed = clamp(
            float(speed)
            * min(1.0, self.speed_multiplier / 2.0)
            + min(1.0, self.speed_multiplier / 4.0) * 0.20
        )

        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=effective_speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
            music_id=music_id,
            bpm=bpm,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
        )

        if danger is None:
            danger = self._danger_of(object_type)

        danger = clamp(danger)

        learned_mode = self.mode_skill(
            self.game_mode,
            object_type,
        )

        # Навык конкретного режима добавляет небольшой бонус
        # к уверенности/силе управления.
        mode_bonus = (
            learned_mode["confidence"]
            * learned_mode["success_rate"]
            * 0.18
        )

        control_score = clamp(
            base["jump_score"]
            + mode_bonus
        )

        control = self._mode_control_from_score(
            self.game_mode,
            control_score,
            danger,
            self.gravity,
        )

        base["mode"] = {
            "name": self.game_mode,
            "gravity": self.gravity,
            "speed_multiplier": self.speed_multiplier,
            "skill": learned_mode,
        }

        base["control"] = control

        # Для совместимости:
        # jump=True только в режимах с дискретным прыжком.
        base["action"] = control["action"]
        base["jump"] = bool(control["jump"])
        base["hold"] = bool(control["hold"])
        base["vertical"] = float(control["vertical"])
        base["confidence"] = max(
            base["confidence"],
            control_score,
        )

        return base

    def learn_game_result(
        self,
        object_type: str,
        action: str,
        success: bool,
        timing: float = 0.5,
        progress: float = 0.0,
        music_id: Optional[str] = None,
        beat_phase: Optional[float] = None,
        beat_strength: float = 1.0,

        # v8
        game_mode: Optional[str] = None,
        control_strength: float = 0.5,
    ):
        mode = (
            self.game_mode
            if game_mode is None
            else str(game_mode).lower()
        )

        super().learn_game_result(
            object_type=object_type,
            action=action,
            success=success,
            timing=timing,
            progress=progress,
            music_id=music_id,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
        )

        self.learn_mode_skill(
            mode,
            object_type,
            success,
            control_strength,
        )

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "game_mode": self.game_mode,
            "gravity": self.gravity,
            "speed_multiplier": self.speed_multiplier,
            "mode_skill_memory": self.mode_skill_memory,
            "portal_memory": self.portal_memory[-128:],
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v8.json",
    ):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v8.json",
    ):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V9
# Память смертей + исправление ошибок следующей попытки
# ======================================================================

BaseFlyBrainModelV8 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV8):
    VERSION = 9

    MAX_DEATH_EVENTS = 256

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # Контекстная память смертей.
        # key = mode|gravity|speed_bucket|object
        self.death_memory = saved.get("death_memory", {})

        # Последние отдельные события смерти для анализа.
        self.death_events = list(
            saved.get("death_events", [])
        )[-self.MAX_DEATH_EVENTS:]

        self.total_deaths = int(
            saved.get("total_deaths", 0)
        )

        self.last_death = (
            self.death_events[-1]
            if self.death_events
            else None
        )

    # ------------------------------------------------------------------
    # DEATH MEMORY
    # ------------------------------------------------------------------

    def _death_key(
        self,
        object_type: str,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> str:
        return self.context_key(
            object_type=object_type,
            game_mode=game_mode,
            gravity=gravity,
            speed_multiplier=speed_multiplier,
        )

    def _death_bucket(
        self,
        object_type: str,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:
        key = self._death_key(
            object_type,
            game_mode,
            gravity,
            speed_multiplier,
        )

        return self.death_memory.setdefault(
            key,
            {
                "deaths": 0,
                "wait_deaths": 0,
                "jump_deaths": 0,
                "escape_deaths": 0,
                "hold_deaths": 0,

                # Средняя дистанция до объекта в момент ошибки.
                "mean_distance": 0.5,

                # Средний прогресс уровня, где происходила ошибка.
                "mean_progress": 0.0,

                # Изученный момент, где лучше действовать.
                "preferred_distance": 0.45,

                # Сила корректировки 0..1.
                "correction_confidence": 0.0,

                # Последняя причина.
                "last_cause": "",
            },
        )

    def record_death(
        self,
        object_type: str,
        action: str,
        distance: float,
        progress: float,
        cause: str = "collision",
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Записывает одну смерть.

        object_type:
            spike / saw / laser / custom_trap / ...

        action:
            wait / jump / escape / hold / thrust / flap / ...
        """
        object_type = str(object_type).lower()
        action = str(action).lower()
        distance = clamp(distance)
        progress = clamp(progress)

        mode = (
            self.game_mode
            if game_mode is None
            else str(game_mode).lower()
        )

        grav = (
            self.gravity
            if gravity is None
            else (1.0 if float(gravity) >= 0 else -1.0)
        )

        speed_mult = (
            self.speed_multiplier
            if speed_multiplier is None
            else max(0.25, min(4.0, float(speed_multiplier)))
        )

        bucket = self._death_bucket(
            object_type,
            mode,
            grav,
            speed_mult,
        )

        bucket["deaths"] += 1

        if action in ("wait", "glide", "coast"):
            bucket["wait_deaths"] += 1
        elif action in ("jump", "flap", "thrust", "wave_up"):
            bucket["jump_deaths"] += 1
        elif action == "escape":
            bucket["escape_deaths"] += 1
        elif action == "hold":
            bucket["hold_deaths"] += 1

        n = bucket["deaths"]

        # Онлайн-среднее.
        bucket["mean_distance"] += (
            distance - bucket["mean_distance"]
        ) / n

        bucket["mean_progress"] += (
            progress - bucket["mean_progress"]
        ) / n

        # Если смерть произошла после ожидания,
        # нужно действовать раньше, то есть на большей дистанции.
        if action in ("wait", "glide", "coast"):
            target = clamp(distance + 0.12)
        else:
            # Если уже прыгал/держал, сохраняем наблюдаемую точку,
            # но с меньшим сдвигом.
            target = clamp(distance + 0.03)

        alpha = 0.22 if n <= 5 else 0.10

        bucket["preferred_distance"] = (
            float(bucket["preferred_distance"])
            * (1.0 - alpha)
            + target * alpha
        )

        # Чем больше повторений одной ошибки, тем сильнее память.
        bucket["correction_confidence"] = clamp(
            n / 8.0
        )

        bucket["last_cause"] = str(cause)

        event = {
            "time": self.age,
            "object": object_type,
            "action": action,
            "distance": distance,
            "progress": progress,
            "cause": str(cause),
            "mode": mode,
            "gravity": grav,
            "speed_multiplier": speed_mult,
        }

        self.death_events.append(event)

        if len(self.death_events) > self.MAX_DEATH_EVENTS:
            self.death_events = self.death_events[-self.MAX_DEATH_EVENTS:]

        self.total_deaths += 1
        self.last_death = event

        # Смерть — отрицательная награда.
        self.add_reward(
            -0.28 - (1.0 - progress) * 0.12
        )

        return bucket

    def death_correction(
        self,
        object_type: str,
        distance: float,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Возвращает совет, основанный на прошлых смертях.
        """
        distance = clamp(distance)

        key = self._death_key(
            object_type,
            game_mode,
            gravity,
            speed_multiplier,
        )

        bucket = self.death_memory.get(key)

        if not bucket:
            return {
                "known": False,
                "confidence": 0.0,
                "recommended_action": None,
                "preferred_distance": 0.5,
                "urgency": 0.0,
            }

        deaths = max(1, int(bucket["deaths"]))
        wait_ratio = int(bucket["wait_deaths"]) / deaths
        jump_ratio = int(bucket["jump_deaths"]) / deaths

        confidence = clamp(
            bucket["correction_confidence"]
        )

        preferred = clamp(
            bucket["preferred_distance"]
        )

        # Если большинство смертей были от ожидания,
        # мозг явно учится действовать раньше.
        if wait_ratio >= 0.45:
            recommended = "jump"
        elif jump_ratio >= 0.65:
            # Возможно, прыжок был слишком поздним/не тем управлением.
            recommended = "earlier_control"
        else:
            recommended = "caution"

        # Чем ближе мы к изученной зоне смерти,
        # тем выше срочность корректировки.
        diff = abs(distance - preferred)

        urgency = clamp(
            1.0 - diff / 0.35
        ) * confidence

        return {
            "known": True,
            "confidence": confidence,
            "recommended_action": recommended,
            "preferred_distance": preferred,
            "urgency": urgency,
            "deaths": deaths,
            "wait_ratio": wait_ratio,
            "jump_ratio": jump_ratio,
            "cause": bucket.get("last_cause", ""),
        }

    # ------------------------------------------------------------------
    # HIGH-LEVEL DEATH HOOK
    # ------------------------------------------------------------------

    def on_death(
        self,
        object_type: str,
        distance: float,
        progress: float,
        action: Optional[str] = None,
        cause: str = "collision",
    ) -> Dict[str, Any]:
        """
        Удобно вызывать из игры сразу при смерти.

        Если action не передан, пытаемся взять его
        из последнего плана/контекста.
        """
        if action is None:
            if self.last_plan:
                action = self.last_plan[0].get("action", "wait")
            else:
                action = "wait"

        bucket = self.record_death(
            object_type=object_type,
            action=action,
            distance=distance,
            progress=progress,
            cause=cause,
        )

        # Обучаем объект как неуспешный.
        self.learn_game_result(
            object_type=object_type,
            action=action,
            success=False,
            timing=clamp(1.0 - distance),
            progress=progress,
            game_mode=self.game_mode,
            control_strength=0.0,
        )

        # Завершаем текущий эпизод как неудачный.
        if self.current_episode is not None:
            self.finish_episode(
                success=False,
                reward=-0.8,
                progress=progress,
            )

        return {
            "death": self.last_death,
            "memory": bucket,
            "correction": self.death_correction(
                object_type,
                distance,
            ),
        }

    # ------------------------------------------------------------------
    # DECISION WITH ERROR CORRECTION
    # ------------------------------------------------------------------

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,

        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:

        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
            music_id=music_id,
            bpm=bpm,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
            game_mode=game_mode,
            gravity=gravity,
            speed_multiplier=speed_multiplier,
        )

        correction = self.death_correction(
            object_type=object_type,
            distance=distance,
            game_mode=self.game_mode,
            gravity=self.gravity,
            speed_multiplier=self.speed_multiplier,
        )

        base["death_correction"] = correction

        if not correction["known"]:
            return base

        urgency = correction["urgency"]
        recommendation = correction["recommended_action"]

        # ----------------------------------------------------------
        # Дискретные режимы: cube/ufo
        # ----------------------------------------------------------
        if self.game_mode in ("cube", "ufo"):
            if (
                recommendation == "jump"
                and urgency >= 0.45
            ):
                base["control"] = {
                    "action": "jump" if self.game_mode == "cube" else "flap",
                    "jump": True,
                    "hold": False,
                    "vertical": 0.0,
                }

                base["action"] = base["control"]["action"]
                base["jump"] = True
                base["hold"] = False

                base["confidence"] = max(
                    base["confidence"],
                    urgency,
                )

                base["jump_score"] = clamp(
                    base["jump_score"]
                    + urgency * 0.35
                )

        # ----------------------------------------------------------
        # Непрерывные режимы: fly/ship
        # ----------------------------------------------------------
        elif self.game_mode in ("fly", "ship"):
            if recommendation in ("jump", "earlier_control") and urgency >= 0.40:
                action = (
                    "flap"
                    if self.game_mode == "fly"
                    else "thrust"
                )

                strength = clamp(
                    0.45 + urgency * 0.50
                )

                gravity_sign = (
                    1.0 if self.gravity >= 0
                    else -1.0
                )

                base["control"] = {
                    "action": action,
                    "jump": False,
                    "hold": True,
                    "vertical": gravity_sign * strength,
                }

                base["action"] = action
                base["jump"] = False
                base["hold"] = True
                base["vertical"] = gravity_sign * strength
                base["confidence"] = max(
                    base["confidence"],
                    urgency,
                )

        # ----------------------------------------------------------
        # Wave: корректируем направление заранее.
        # ----------------------------------------------------------
        elif self.game_mode == "wave":
            if urgency >= 0.45:
                gravity_sign = (
                    1.0 if self.gravity >= 0
                    else -1.0
                )

                base["control"] = {
                    "action": "wave_up",
                    "jump": False,
                    "hold": True,
                    "vertical": gravity_sign,
                }

                base["action"] = "wave_up"
                base["hold"] = True
                base["vertical"] = gravity_sign

        return base

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "death_memory": self.death_memory,
            "death_events": self.death_events[-self.MAX_DEATH_EVENTS:],
            "total_deaths": self.total_deaths,
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v9.json",
    ):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v9.json",
    ):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V10
# Память целых маршрутов уровня
# ======================================================================

BaseFlyBrainModelV9 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV9):
    VERSION = 10

    MAX_ROUTES_PER_LEVEL = 24
    MAX_ROUTE_STEPS = 256

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # level_id -> [route, route, ...]
        self.route_memory = saved.get(
            "route_memory",
            {},
        )

        # Текущий записываемый маршрут.
        self.current_route = None

        # Последняя подсказка маршрута.
        self.last_route_hint = None

    # ------------------------------------------------------------------
    # ROUTE RECORDING
    # ------------------------------------------------------------------

    def start_route(
        self,
        level_id: str,
    ):
        self.current_route = {
            "level_id": str(level_id),
            "started_at": float(self.age),
            "steps": [],
        }

    def _record_route_step(
        self,
        level_id: Optional[str],
        level_progress: Optional[float],
        object_type: str,
        distance: float,
        decision: Dict[str, Any],
    ):
        if self.current_route is None:
            return

        if level_id is not None:
            if str(level_id) != self.current_route["level_id"]:
                return

        progress = (
            0.0
            if level_progress is None
            else clamp(level_progress)
        )

        steps = self.current_route["steps"]

        action = str(
            decision.get("action", "wait")
        )

        step = {
            "time": float(self.age),
            "progress": progress,
            "object": str(object_type).lower(),
            "distance": clamp(distance),
            "mode": self.game_mode,
            "gravity": self.gravity,
            "speed_multiplier": self.speed_multiplier,
            "action": action,
            "confidence": clamp(
                decision.get("confidence", 0.0)
            ),
            "jump": bool(
                decision.get("jump", False)
            ),
            "hold": bool(
                decision.get("hold", False)
            ),
            "vertical": float(
                decision.get("vertical", 0.0)
            ),
        }

        # Не записываем сотни одинаковых кадров.
        if steps:
            last = steps[-1]

            same_context = (
                last["object"] == step["object"]
                and last["mode"] == step["mode"]
                and last["action"] == step["action"]
                and abs(
                    last["progress"] - step["progress"]
                ) < 0.008
            )

            if same_context:
                # Обновляем самое близкое расстояние и уверенность.
                last["distance"] = min(
                    last["distance"],
                    step["distance"],
                )
                last["confidence"] = max(
                    last["confidence"],
                    step["confidence"],
                )
                return

        steps.append(step)

        if len(steps) > self.MAX_ROUTE_STEPS:
            del steps[:-self.MAX_ROUTE_STEPS]

    def finish_route(
        self,
        success: bool,
        reward: float = 0.0,
        progress: float = 1.0,
    ):
        if self.current_route is None:
            return None

        steps = list(
            self.current_route.get("steps", [])
        )

        if not steps:
            self.current_route = None
            return None

        route = {
            "level_id": self.current_route["level_id"],
            "success": bool(success),
            "reward": max(
                -1.0,
                min(1.0, float(reward)),
            ),
            "progress": clamp(progress),
            "duration": max(
                0.0,
                float(self.age)
                - float(self.current_route["started_at"]),
            ),
            "steps": steps,
        }

        level_id = route["level_id"]

        routes = self.route_memory.setdefault(
            level_id,
            [],
        )

        routes.append(route)

        # Храним лучшие успешные + несколько недавних неудачных.
        routes.sort(
            key=lambda r: (
                bool(r.get("success", False)),
                float(r.get("progress", 0.0)),
                float(r.get("reward", 0.0)),
            ),
            reverse=True,
        )

        if len(routes) > self.MAX_ROUTES_PER_LEVEL:
            del routes[self.MAX_ROUTES_PER_LEVEL:]

        self.current_route = None

        if success:
            self.add_reward(
                0.25 + max(0.0, reward) * 0.20
            )
        else:
            self.add_reward(
                -0.12 * (1.0 - clamp(progress) * 0.4)
            )

        return route

    # ------------------------------------------------------------------
    # ROUTE RECALL
    # ------------------------------------------------------------------

    def recall_route_action(
        self,
        level_id: str,
        level_progress: float,
        object_type: str,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:
        level_id = str(level_id)
        level_progress = clamp(level_progress)
        object_type = str(object_type).lower()

        routes = self.route_memory.get(
            level_id,
            [],
        )

        if not routes:
            return {
                "found": False,
                "action": None,
                "confidence": 0.0,
                "route_progress": None,
                "distance": None,
                "jump": False,
                "hold": False,
                "vertical": 0.0,
            }

        mode = (
            self.game_mode
            if game_mode is None
            else str(game_mode).lower()
        )

        grav = (
            self.gravity
            if gravity is None
            else (
                1.0
                if float(gravity) >= 0
                else -1.0
            )
        )

        speed_mult = (
            self.speed_multiplier
            if speed_multiplier is None
            else max(
                0.25,
                min(4.0, float(speed_multiplier)),
            )
        )

        candidates = []

        for route in routes:
            if not route.get("success", False):
                continue

            route_reward = max(
                0.0,
                float(route.get("reward", 0.0)),
            )

            route_progress = clamp(
                route.get("progress", 1.0)
            )

            for step in route.get("steps", []):
                if step.get("object") != object_type:
                    continue

                if step.get("mode") != mode:
                    continue

                step_gravity = (
                    1.0
                    if float(step.get("gravity", 1.0)) >= 0
                    else -1.0
                )

                if step_gravity != grav:
                    continue

                step_speed = float(
                    step.get(
                        "speed_multiplier",
                        1.0,
                    )
                )

                # Допускаем близкие скорости, но не совершенно разные.
                speed_difference = abs(
                    step_speed - speed_mult
                )

                if speed_difference > 0.75:
                    continue

                progress_difference = abs(
                    float(step.get("progress", 0.0))
                    - level_progress
                )

                # Маршрутная подсказка должна относиться
                # к близкому месту уровня.
                if progress_difference > 0.08:
                    continue

                progress_match = clamp(
                    1.0 - progress_difference / 0.08
                )

                speed_match = clamp(
                    1.0 - speed_difference / 0.75
                )

                step_conf = clamp(
                    step.get("confidence", 0.0)
                )

                score = (
                    progress_match * 0.52
                    + speed_match * 0.12
                    + route_progress * 0.16
                    + route_reward * 0.10
                    + step_conf * 0.10
                )

                candidates.append(
                    (
                        score,
                        step,
                        route,
                    )
                )

        if not candidates:
            return {
                "found": False,
                "action": None,
                "confidence": 0.0,
                "route_progress": None,
                "distance": None,
                "jump": False,
                "hold": False,
                "vertical": 0.0,
            }

        candidates.sort(
            key=lambda item: item[0],
            reverse=True,
        )

        score, step, route = candidates[0]

        # Несколько успешных маршрутов с одинаковым действием
        # повышают доверие к нему.
        same_action_support = 0

        for candidate_score, candidate_step, _ in candidates[:8]:
            if (
                candidate_step.get("action")
                == step.get("action")
                and candidate_score >= score * 0.75
            ):
                same_action_support += 1

        support_bonus = min(
            0.12,
            same_action_support * 0.02,
        )

        confidence = clamp(
            score + support_bonus
        )

        result = {
            "found": True,
            "action": step.get("action", "wait"),
            "confidence": confidence,
            "route_progress": float(
                step.get("progress", 0.0)
            ),
            "distance": clamp(
                step.get("distance", 1.0)
            ),
            "jump": bool(
                step.get("jump", False)
            ),
            "hold": bool(
                step.get("hold", False)
            ),
            "vertical": float(
                step.get("vertical", 0.0)
            ),
            "source_route_reward": float(
                route.get("reward", 0.0)
            ),
            "support": same_action_support,
        }

        self.last_route_hint = result
        return result

    # ------------------------------------------------------------------
    # ROUTE-AWARE DECISION
    # ------------------------------------------------------------------

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,

        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,

        # v10
        level_id: Optional[str] = None,
        level_progress: Optional[float] = None,
    ) -> Dict[str, Any]:

        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
            music_id=music_id,
            bpm=bpm,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
            game_mode=game_mode,
            gravity=gravity,
            speed_multiplier=speed_multiplier,
        )

        route_hint = {
            "found": False,
            "action": None,
            "confidence": 0.0,
        }

        if (
            level_id is not None
            and level_progress is not None
        ):
            route_hint = self.recall_route_action(
                level_id=level_id,
                level_progress=level_progress,
                object_type=object_type,
                game_mode=self.game_mode,
                gravity=self.gravity,
                speed_multiplier=self.speed_multiplier,
            )

        base["route"] = route_hint

        # ----------------------------------------------------------
        # Конфликт route memory vs death memory:
        # память смерти имеет приоритет, если её уверенность выше.
        # ----------------------------------------------------------
        death_hint = base.get(
            "death_correction",
            {},
        )

        death_conf = float(
            death_hint.get(
                "confidence",
                0.0,
            )
        )

        route_conf = float(
            route_hint.get(
                "confidence",
                0.0,
            )
        )

        base_is_emergency = (
            base.get("escape", False)
            or base.get("action") == "escape"
        )

        if (
            route_hint.get("found")
            and route_conf >= 0.58
            and route_conf > death_conf
            and not base_is_emergency
        ):
            route_action = str(
                route_hint.get(
                    "action",
                    "wait",
                )
            )

            # Cube/UFO
            if self.game_mode in ("cube", "ufo"):
                if route_hint.get("jump", False) or route_action in (
                    "jump",
                    "flap",
                ):
                    action = (
                        "jump"
                        if self.game_mode == "cube"
                        else "flap"
                    )

                    base["control"] = {
                        "action": action,
                        "jump": True,
                        "hold": False,
                        "vertical": 0.0,
                    }

                    base["action"] = action
                    base["jump"] = True
                    base["hold"] = False

                elif route_action == "wait":
                    base["control"] = {
                        "action": "wait",
                        "jump": False,
                        "hold": False,
                        "vertical": 0.0,
                    }

                    base["action"] = "wait"
                    base["jump"] = False
                    base["hold"] = False

            # Fly/Ship
            elif self.game_mode in ("fly", "ship"):
                route_hold = bool(
                    route_hint.get("hold", False)
                )

                if route_hold or route_action in (
                    "flap",
                    "thrust",
                ):
                    action = (
                        "flap"
                        if self.game_mode == "fly"
                        else "thrust"
                    )

                    vertical = float(
                        route_hint.get(
                            "vertical",
                            0.0,
                        )
                    )

                    base["control"] = {
                        "action": action,
                        "jump": False,
                        "hold": True,
                        "vertical": vertical,
                    }

                    base["action"] = action
                    base["jump"] = False
                    base["hold"] = True
                    base["vertical"] = vertical

                elif route_action in ("glide", "coast", "wait"):
                    action = (
                        "glide"
                        if self.game_mode == "fly"
                        else "coast"
                    )

                    base["control"] = {
                        "action": action,
                        "jump": False,
                        "hold": False,
                        "vertical": 0.0,
                    }

                    base["action"] = action
                    base["hold"] = False
                    base["vertical"] = 0.0

            # Wave
            elif self.game_mode == "wave":
                vertical = float(
                    route_hint.get(
                        "vertical",
                        0.0,
                    )
                )

                if vertical >= 0:
                    action = "wave_up"
                    hold = True
                else:
                    action = "wave_down"
                    hold = False

                base["control"] = {
                    "action": action,
                    "jump": False,
                    "hold": hold,
                    "vertical": vertical,
                }

                base["action"] = action
                base["hold"] = hold
                base["vertical"] = vertical

            base["confidence"] = max(
                base.get("confidence", 0.0),
                route_conf,
            )

        # Записываем уже итоговое решение,
        # то есть после memory/death/route correction.
        self._record_route_step(
            level_id=level_id,
            level_progress=level_progress,
            object_type=object_type,
            distance=distance,
            decision=base,
        )

        return base

    # ------------------------------------------------------------------
    # DEATH IN ROUTE
    # ------------------------------------------------------------------

    def on_death(
        self,
        object_type: str,
        distance: float,
        progress: float,
        action: Optional[str] = None,
        cause: str = "collision",
    ) -> Dict[str, Any]:

        result = super().on_death(
            object_type=object_type,
            distance=distance,
            progress=progress,
            action=action,
            cause=cause,
        )

        # Если параллельно записывался маршрут,
        # сохраняем его как неудачный.
        if self.current_route is not None:
            route = self.finish_route(
                success=False,
                reward=-0.8,
                progress=progress,
            )

            result["route"] = route

        return result

    # ------------------------------------------------------------------
    # ROUTE CONSOLIDATION
    # ------------------------------------------------------------------

    def consolidate_routes(self):
        removed = 0

        for level_id in list(
            self.route_memory.keys()
        ):
            routes = self.route_memory[level_id]

            successful = [
                r for r in routes
                if r.get("success", False)
            ]

            failed = [
                r for r in routes
                if not r.get("success", False)
            ]

            successful.sort(
                key=lambda r: (
                    float(r.get("progress", 0.0)),
                    float(r.get("reward", 0.0)),
                    -float(r.get("duration", 999999.0)),
                ),
                reverse=True,
            )

            failed.sort(
                key=lambda r: (
                    float(r.get("progress", 0.0)),
                    float(r.get("reward", -1.0)),
                ),
                reverse=True,
            )

            # Лучшие успешные и несколько самых полезных неудачных.
            kept = (
                successful[:18]
                + failed[:4]
            )

            removed += max(
                0,
                len(routes) - len(kept),
            )

            if kept:
                self.route_memory[level_id] = kept
            else:
                del self.route_memory[level_id]

        return {
            "levels": len(self.route_memory),
            "routes": sum(
                len(v)
                for v in self.route_memory.values()
            ),
            "removed": removed,
        }

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "route_memory": self.route_memory,
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v10.json",
    ):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v10.json",
    ):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V11
# Глобальные навыки и перенос опыта между уровнями
# ======================================================================

BaseFlyBrainModelV10 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV10):
    VERSION = 11

    MAX_GLOBAL_SKILLS = 512

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # Универсальная библиотека навыков.
        #
        # key:
        # mode|g=...|s=...|objA>objB>objC
        #
        # value:
        # samples, success, action_votes, vertical_mean ...
        self.global_skill_library = saved.get(
            "global_skill_library",
            {},
        )

        self.last_global_skill = None

    # ------------------------------------------------------------------
    # SIGNATURES
    # ------------------------------------------------------------------

    @staticmethod
    def _speed_bucket_value(speed_multiplier: float) -> float:
        return round(float(speed_multiplier) * 2.0) / 2.0

    def _skill_key(
        self,
        sequence: List[str],
        mode: str,
        gravity: float,
        speed_multiplier: float,
    ) -> str:
        objects = ">".join(
            str(x).lower()
            for x in sequence
        )

        return (
            f"{str(mode).lower()}|"
            f"g={1 if float(gravity) >= 0 else -1}|"
            f"s={self._speed_bucket_value(speed_multiplier):.1f}|"
            f"{objects}"
        )

    # ------------------------------------------------------------------
    # LEARN SKILLS FROM SUCCESSFUL ROUTES
    # ------------------------------------------------------------------

    def _learn_global_skills_from_route(
        self,
        route: Dict[str, Any],
    ):
        if not route or not route.get("success", False):
            return

        steps = route.get("steps", [])

        if not steps:
            return

        route_reward = max(
            -1.0,
            min(1.0, float(route.get("reward", 0.0))),
        )

        for i, step in enumerate(steps):
            current_obj = str(
                step.get("object", "")
            ).lower()

            if not current_obj:
                continue

            mode = str(
                step.get("mode", "fly")
            ).lower()

            gravity = float(
                step.get("gravity", 1.0)
            )

            speed_multiplier = float(
                step.get("speed_multiplier", 1.0)
            )

            # Учим фрагменты длиной 1..4,
            # заканчивающиеся текущим объектом.
            for length in range(1, 5):
                start = i - length + 1

                if start < 0:
                    continue

                seq_steps = steps[start:i + 1]
                sequence = [
                    str(s.get("object", "")).lower()
                    for s in seq_steps
                ]

                if any(not x for x in sequence):
                    continue

                # Контекст фрагмента берём по текущему шагу.
                key = self._skill_key(
                    sequence,
                    mode,
                    gravity,
                    speed_multiplier,
                )

                data = self.global_skill_library.setdefault(
                    key,
                    {
                        "samples": 0,
                        "successful_samples": 0,
                        "action_votes": {},
                        "jump_votes": 0,
                        "hold_votes": 0,
                        "vertical_sum": 0.0,
                        "confidence_sum": 0.0,
                        "reward_sum": 0.0,
                        "levels": [],
                    },
                )

                data["samples"] += 1
                data["successful_samples"] += 1

                action = str(
                    step.get("action", "wait")
                )

                votes = data["action_votes"]
                votes[action] = int(
                    votes.get(action, 0)
                ) + 1

                if step.get("jump", False):
                    data["jump_votes"] += 1

                if step.get("hold", False):
                    data["hold_votes"] += 1

                data["vertical_sum"] += float(
                    step.get("vertical", 0.0)
                )

                data["confidence_sum"] += clamp(
                    step.get("confidence", 0.0)
                )

                data["reward_sum"] += route_reward

                level_id = str(
                    route.get("level_id", "")
                )

                if (
                    level_id
                    and level_id not in data["levels"]
                    and len(data["levels"]) < 12
                ):
                    data["levels"].append(level_id)

        self._trim_global_skills()

    def _trim_global_skills(self):
        if len(self.global_skill_library) <= self.MAX_GLOBAL_SKILLS:
            return

        ranked = sorted(
            self.global_skill_library.items(),
            key=lambda kv: (
                int(kv[1].get("samples", 0)),
                float(kv[1].get("reward_sum", 0.0)),
            ),
            reverse=True,
        )

        self.global_skill_library = dict(
            ranked[:self.MAX_GLOBAL_SKILLS]
        )

    def finish_route(
        self,
        success: bool,
        reward: float = 0.0,
        progress: float = 1.0,
    ):
        route = super().finish_route(
            success=success,
            reward=reward,
            progress=progress,
        )

        if route and success:
            self._learn_global_skills_from_route(
                route
            )

        return route

    # ------------------------------------------------------------------
    # SKILL RECALL
    # ------------------------------------------------------------------

    def _recent_object_sequence(
        self,
        current_object: str,
        max_len: int = 4,
    ) -> List[str]:
        labels = self.working_memory.last_labels(
            self.age,
            count=max_len,
        )

        labels = [
            str(x).lower()
            for x in labels
            if x and not str(x).startswith("portal:")
        ]

        current_object = str(
            current_object
        ).lower()

        if not labels or labels[-1] != current_object:
            labels.append(current_object)

        return labels[-max_len:]

    def recall_global_skill(
        self,
        object_type: str,
        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,
    ) -> Dict[str, Any]:

        mode = (
            self.game_mode
            if game_mode is None
            else str(game_mode).lower()
        )

        grav = (
            self.gravity
            if gravity is None
            else (
                1.0
                if float(gravity) >= 0
                else -1.0
            )
        )

        speed_mult = (
            self.speed_multiplier
            if speed_multiplier is None
            else float(speed_multiplier)
        )

        recent = self._recent_object_sequence(
            object_type,
            max_len=4,
        )

        best = None

        # Сначала ищем самый длинный знакомый фрагмент.
        for length in range(
            min(4, len(recent)),
            0,
            -1,
        ):
            sequence = recent[-length:]

            key = self._skill_key(
                sequence,
                mode,
                grav,
                speed_mult,
            )

            data = self.global_skill_library.get(
                key
            )

            if not data:
                continue

            samples = max(
                1,
                int(data.get("samples", 0)),
            )

            successes = int(
                data.get(
                    "successful_samples",
                    0,
                )
            )

            success_rate = (
                successes / samples
            )

            experience = clamp(
                samples / 12.0
            )

            action_votes = data.get(
                "action_votes",
                {},
            )

            if action_votes:
                action = max(
                    action_votes,
                    key=action_votes.get,
                )
                action_agreement = (
                    action_votes[action] / samples
                )
            else:
                action = "wait"
                action_agreement = 0.0

            avg_confidence = clamp(
                float(
                    data.get(
                        "confidence_sum",
                        0.0,
                    )
                ) / samples
            )

            # Чем длиннее последовательность, тем
            # информативнее совпадение.
            sequence_specificity = (
                length / 4.0
            )

            confidence = clamp(
                success_rate * 0.30
                + experience * 0.22
                + action_agreement * 0.24
                + avg_confidence * 0.14
                + sequence_specificity * 0.10
            )

            jump_ratio = (
                int(data.get("jump_votes", 0))
                / samples
            )

            hold_ratio = (
                int(data.get("hold_votes", 0))
                / samples
            )

            vertical = float(
                data.get("vertical_sum", 0.0)
            ) / samples

            best = {
                "found": True,
                "sequence": sequence,
                "length": length,
                "action": action,
                "confidence": confidence,
                "success_rate": success_rate,
                "samples": samples,
                "jump": jump_ratio >= 0.5,
                "hold": hold_ratio >= 0.5,
                "vertical": vertical,
                "source_levels": list(
                    data.get("levels", [])
                ),
            }

            break

        if best is None:
            return {
                "found": False,
                "sequence": recent,
                "length": 0,
                "action": None,
                "confidence": 0.0,
                "success_rate": 0.0,
                "samples": 0,
                "jump": False,
                "hold": False,
                "vertical": 0.0,
                "source_levels": [],
            }

        self.last_global_skill = best
        return best

    # ------------------------------------------------------------------
    # TRANSFER-AWARE DECISION
    # ------------------------------------------------------------------

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,

        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,

        level_id: Optional[str] = None,
        level_progress: Optional[float] = None,
    ) -> Dict[str, Any]:

        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
            music_id=music_id,
            bpm=bpm,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
            game_mode=game_mode,
            gravity=gravity,
            speed_multiplier=speed_multiplier,
            level_id=level_id,
            level_progress=level_progress,
        )

        skill = self.recall_global_skill(
            object_type=object_type,
            game_mode=self.game_mode,
            gravity=self.gravity,
            speed_multiplier=self.speed_multiplier,
        )

        base["global_skill"] = skill

        if not skill["found"]:
            return base

        skill_conf = float(
            skill.get("confidence", 0.0)
        )

        death_conf = float(
            base.get(
                "death_correction",
                {},
            ).get(
                "confidence",
                0.0,
            )
        )

        route_conf = float(
            base.get(
                "route",
                {},
            ).get(
                "confidence",
                0.0,
            )
        )

        emergency = (
            base.get("escape", False)
            or base.get("action") == "escape"
        )

        # Сильная память смерти важнее transfer skill.
        # Точный маршрут этого же уровня тоже важнее,
        # если его уверенность выше.
        can_transfer = (
            skill_conf >= 0.60
            and skill_conf > death_conf
            and skill_conf > route_conf
            and not emergency
        )

        if not can_transfer:
            return base

        action = str(
            skill.get(
                "action",
                "wait",
            )
        )

        # Cube / UFO
        if self.game_mode in ("cube", "ufo"):
            if skill.get("jump", False) or action in (
                "jump",
                "flap",
            ):
                mapped = (
                    "jump"
                    if self.game_mode == "cube"
                    else "flap"
                )

                base["control"] = {
                    "action": mapped,
                    "jump": True,
                    "hold": False,
                    "vertical": 0.0,
                }

                base["action"] = mapped
                base["jump"] = True
                base["hold"] = False

            elif action == "wait":
                base["control"] = {
                    "action": "wait",
                    "jump": False,
                    "hold": False,
                    "vertical": 0.0,
                }

                base["action"] = "wait"
                base["jump"] = False
                base["hold"] = False

        # Fly / Ship
        elif self.game_mode in ("fly", "ship"):
            if skill.get("hold", False) or action in (
                "flap",
                "thrust",
            ):
                mapped = (
                    "flap"
                    if self.game_mode == "fly"
                    else "thrust"
                )

                vertical = float(
                    skill.get(
                        "vertical",
                        0.0,
                    )
                )

                base["control"] = {
                    "action": mapped,
                    "jump": False,
                    "hold": True,
                    "vertical": vertical,
                }

                base["action"] = mapped
                base["jump"] = False
                base["hold"] = True
                base["vertical"] = vertical

            elif action in (
                "glide",
                "coast",
                "wait",
            ):
                mapped = (
                    "glide"
                    if self.game_mode == "fly"
                    else "coast"
                )

                base["control"] = {
                    "action": mapped,
                    "jump": False,
                    "hold": False,
                    "vertical": 0.0,
                }

                base["action"] = mapped
                base["hold"] = False
                base["vertical"] = 0.0

        # Wave
        elif self.game_mode == "wave":
            vertical = float(
                skill.get(
                    "vertical",
                    0.0,
                )
            )

            mapped = (
                "wave_up"
                if vertical >= 0
                else "wave_down"
            )

            base["control"] = {
                "action": mapped,
                "jump": False,
                "hold": vertical >= 0,
                "vertical": vertical,
            }

            base["action"] = mapped
            base["jump"] = False
            base["hold"] = vertical >= 0
            base["vertical"] = vertical

        base["confidence"] = max(
            base.get("confidence", 0.0),
            skill_conf,
        )

        return base

    # ------------------------------------------------------------------
    # GLOBAL SKILL CONSOLIDATION
    # ------------------------------------------------------------------

    def consolidate_global_skills(self):
        removed = 0

        for key in list(
            self.global_skill_library.keys()
        ):
            data = self.global_skill_library[key]

            samples = int(
                data.get("samples", 0)
            )

            successes = int(
                data.get(
                    "successful_samples",
                    0,
                )
            )

            if samples <= 0:
                del self.global_skill_library[key]
                removed += 1
                continue

            success_rate = (
                successes / samples
            )

            # Единичные и слабые навыки забываем.
            if (
                samples == 1
                and success_rate < 0.75
            ):
                del self.global_skill_library[key]
                removed += 1

        self._trim_global_skills()

        return {
            "skills": len(
                self.global_skill_library
            ),
            "removed": removed,
        }

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "global_skill_library": self.global_skill_library,
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v11.json",
    ):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v11.json",
    ):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return cls(json.load(f))
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()



# ======================================================================
# FLY BRAIN V12
# Meta-brain:
# - novelty / curiosity
# - object-family transfer
# - prediction calibration
# - replay memory
# - mental rollout
# - goals / motivation
# - sleep consolidation
# - bounded memories
# - brain report
# ======================================================================

BaseFlyBrainModelV11 = FlyBrainModel


class FlyBrainModel(BaseFlyBrainModelV11):
    VERSION = 12

    MAX_NOVELTY_CONTEXTS = 512
    MAX_REPLAY = 512
    MAX_PREDICTION_CONTEXTS = 256
    MAX_FAMILY_SKILLS = 128

    def __init__(self, saved: Dict[str, Any] | None = None):
        saved = saved or {}
        super().__init__(saved)

        # ----------------------------------------------------------
        # Curiosity / novelty
        # ----------------------------------------------------------
        self.novelty_memory = saved.get(
            "novelty_memory",
            {},
        )

        self.curiosity = clamp(
            saved.get("curiosity", 0.55)
        )

        # ----------------------------------------------------------
        # Generalisation by object family
        # ----------------------------------------------------------
        self.family_skill_memory = saved.get(
            "family_skill_memory",
            {},
        )

        # ----------------------------------------------------------
        # Prediction calibration
        # ----------------------------------------------------------
        self.prediction_calibration = saved.get(
            "prediction_calibration",
            {},
        )

        self.pending_prediction = None

        # ----------------------------------------------------------
        # Replay memory
        # ----------------------------------------------------------
        self.replay_memory = list(
            saved.get("replay_memory", [])
        )[-self.MAX_REPLAY:]

        # ----------------------------------------------------------
        # Goal / motivation system
        # ----------------------------------------------------------
        self.goals = saved.get(
            "goals",
            {
                "survive": 0.85,
                "progress": 0.80,
                "explore": 0.35,
                "collect": 0.25,
            },
        )

        # Keep any old save compatible.
        for key, default in {
            "survive": 0.85,
            "progress": 0.80,
            "explore": 0.35,
            "collect": 0.25,
        }.items():
            self.goals.setdefault(key, default)

        self.last_meta_decision = None

        # Last state for replay learning.
        self._last_state_snapshot = None

    # ------------------------------------------------------------------
    # OBJECT FAMILY GENERALISATION
    # ------------------------------------------------------------------

    @staticmethod
    def object_family(object_type: str) -> str:
        name = str(object_type).lower()

        if "spike" in name:
            return "spike"

        if (
            "saw" in name
            or "laser" in name
            or "trap" in name
            or "hazard" in name
        ):
            return "hazard"

        if "portal" in name:
            return "portal"

        if "orb" in name:
            return "orb"

        if "pad" in name:
            return "pad"

        if (
            "food" in name
            or "coin" in name
            or "key" in name
            or "chest" in name
        ):
            return "reward"

        if "block" in name or "wall" in name:
            return "block"

        return "other"

    def _family_key(
        self,
        object_type: str,
        mode: Optional[str] = None,
        gravity: Optional[float] = None,
    ) -> str:
        mode = (
            self.game_mode
            if mode is None
            else str(mode).lower()
        )

        gravity = (
            self.gravity
            if gravity is None
            else (1.0 if float(gravity) >= 0 else -1.0)
        )

        family = self.object_family(
            object_type
        )

        return (
            f"{mode}|g={int(gravity)}|{family}"
        )

    def learn_family_skill(
        self,
        object_type: str,
        action: str,
        success: bool,
        control_strength: float = 0.5,
        reward: float = 0.0,
    ):
        key = self._family_key(
            object_type
        )

        data = self.family_skill_memory.setdefault(
            key,
            {
                "samples": 0,
                "successes": 0,
                "action_votes": {},
                "control_sum": 0.0,
                "reward_sum": 0.0,
            },
        )

        data["samples"] += 1

        if success:
            data["successes"] += 1

        action = str(action).lower()

        votes = data["action_votes"]
        votes[action] = int(
            votes.get(action, 0)
        ) + 1

        data["control_sum"] += clamp(
            control_strength
        )

        data["reward_sum"] += max(
            -1.0,
            min(1.0, float(reward)),
        )

        self._trim_family_skills()

    def _trim_family_skills(self):
        if len(self.family_skill_memory) <= self.MAX_FAMILY_SKILLS:
            return

        ranked = sorted(
            self.family_skill_memory.items(),
            key=lambda kv: int(
                kv[1].get("samples", 0)
            ),
            reverse=True,
        )

        self.family_skill_memory = dict(
            ranked[:self.MAX_FAMILY_SKILLS]
        )

    def recall_family_skill(
        self,
        object_type: str,
    ) -> Dict[str, Any]:
        key = self._family_key(
            object_type
        )

        data = self.family_skill_memory.get(
            key
        )

        if not data:
            return {
                "found": False,
                "family": self.object_family(
                    object_type
                ),
                "action": None,
                "confidence": 0.0,
                "preferred_control": 0.5,
                "samples": 0,
            }

        samples = max(
            1,
            int(data.get("samples", 0)),
        )

        successes = int(
            data.get("successes", 0)
        )

        votes = data.get(
            "action_votes",
            {},
        )

        if votes:
            action = max(
                votes,
                key=votes.get,
            )
            agreement = (
                votes[action] / samples
            )
        else:
            action = "wait"
            agreement = 0.0

        success_rate = (
            successes / samples
        )

        experience = clamp(
            samples / 16.0
        )

        confidence = clamp(
            success_rate * 0.42
            + agreement * 0.28
            + experience * 0.30
        )

        preferred_control = clamp(
            float(
                data.get(
                    "control_sum",
                    0.0,
                )
            ) / samples
        )

        return {
            "found": True,
            "family": self.object_family(
                object_type
            ),
            "action": action,
            "confidence": confidence,
            "preferred_control": preferred_control,
            "samples": samples,
            "success_rate": success_rate,
        }

    # ------------------------------------------------------------------
    # NOVELTY / CURIOSITY
    # ------------------------------------------------------------------

    def _novelty_key(
        self,
        object_type: str,
    ) -> str:
        return self.context_key(
            object_type=object_type,
            game_mode=self.game_mode,
            gravity=self.gravity,
            speed_multiplier=self.speed_multiplier,
        )

    def novelty_score(
        self,
        object_type: str,
    ) -> float:
        key = self._novelty_key(
            object_type
        )

        data = self.novelty_memory.get(
            key
        )

        visits = (
            int(data.get("visits", 0))
            if data
            else 0
        )

        # First encounter = 1.0.
        # Slowly falls as experience grows.
        return 1.0 / math.sqrt(
            1.0 + visits
        )

    def _observe_novelty(
        self,
        object_type: str,
        reward: float = 0.0,
    ):
        key = self._novelty_key(
            object_type
        )

        data = self.novelty_memory.setdefault(
            key,
            {
                "visits": 0,
                "reward_sum": 0.0,
                "successes": 0,
                "failures": 0,
            },
        )

        data["visits"] += 1
        data["reward_sum"] += float(
            reward
        )

        self._trim_novelty()

    def _trim_novelty(self):
        if len(self.novelty_memory) <= self.MAX_NOVELTY_CONTEXTS:
            return

        ranked = sorted(
            self.novelty_memory.items(),
            key=lambda kv: int(
                kv[1].get("visits", 0)
            ),
            reverse=True,
        )

        self.novelty_memory = dict(
            ranked[:self.MAX_NOVELTY_CONTEXTS]
        )

    # ------------------------------------------------------------------
    # PREDICTION CALIBRATION
    # ------------------------------------------------------------------

    def _prediction_key(
        self,
        previous_object: str,
    ) -> str:
        return (
            f"{self.game_mode}|"
            f"g={int(self.gravity)}|"
            f"{str(previous_object).lower()}"
        )

    def _register_prediction(
        self,
        current_object: str,
    ):
        prediction = self.predict_next_object(
            current_object
        )

        if prediction.get("object") is None:
            self.pending_prediction = None
            return

        self.pending_prediction = {
            "from": str(
                current_object
            ).lower(),
            "predicted": str(
                prediction["object"]
            ).lower(),
            "probability": clamp(
                prediction.get(
                    "probability",
                    0.0,
                )
            ),
        }

    def _score_pending_prediction(
        self,
        actual_object: str,
    ):
        if not self.pending_prediction:
            return

        actual_object = str(
            actual_object
        ).lower()

        pred = self.pending_prediction

        # Do not score same-object frames.
        if actual_object == pred["from"]:
            return

        key = self._prediction_key(
            pred["from"]
        )

        stats = self.prediction_calibration.setdefault(
            key,
            {
                "samples": 0,
                "correct": 0,
                "confidence_sum": 0.0,
                "error_sum": 0.0,
            },
        )

        stats["samples"] += 1
        stats["confidence_sum"] += pred[
            "probability"
        ]

        correct = (
            pred["predicted"]
            == actual_object
        )

        if correct:
            stats["correct"] += 1

        # Simple absolute calibration error.
        target = 1.0 if correct else 0.0

        stats["error_sum"] += abs(
            pred["probability"] - target
        )

        self.pending_prediction = None

        self._trim_prediction_calibration()

    def _trim_prediction_calibration(self):
        if len(self.prediction_calibration) <= self.MAX_PREDICTION_CONTEXTS:
            return

        ranked = sorted(
            self.prediction_calibration.items(),
            key=lambda kv: int(
                kv[1].get("samples", 0)
            ),
            reverse=True,
        )

        self.prediction_calibration = dict(
            ranked[:self.MAX_PREDICTION_CONTEXTS]
        )

    def prediction_accuracy(
        self,
    ) -> Dict[str, float]:
        samples = 0
        correct = 0
        error_sum = 0.0
        conf_sum = 0.0

        for stats in self.prediction_calibration.values():
            samples += int(
                stats.get("samples", 0)
            )
            correct += int(
                stats.get("correct", 0)
            )
            error_sum += float(
                stats.get(
                    "error_sum",
                    0.0,
                )
            )
            conf_sum += float(
                stats.get(
                    "confidence_sum",
                    0.0,
                )
            )

        if samples <= 0:
            return {
                "samples": 0,
                "accuracy": 0.0,
                "mean_confidence": 0.0,
                "mean_error": 0.0,
            }

        return {
            "samples": samples,
            "accuracy": correct / samples,
            "mean_confidence": conf_sum / samples,
            "mean_error": error_sum / samples,
        }

    # ------------------------------------------------------------------
    # OBSERVE OBJECT: prediction + novelty
    # ------------------------------------------------------------------

    def observe_object(
        self,
        object_type: str,
        distance: float,
        danger: float = 0.0,
        value: float = 0.0,
    ):
        obj = str(
            object_type
        ).lower()

        previous = self.last_object

        # Score previous prediction before base updates last_object.
        if (
            previous is not None
            and obj != previous
        ):
            self._score_pending_prediction(
                obj
            )

        data = super().observe_object(
            obj,
            distance,
            danger,
            value,
        )

        # Novelty is counted once per object transition,
        # not every rendered frame.
        if previous != obj:
            self._observe_novelty(
                obj,
                reward=value,
            )
            self._register_prediction(
                obj
            )

        return data

    # ------------------------------------------------------------------
    # GOALS / MOTIVATION
    # ------------------------------------------------------------------

    def update_goals(
        self,
        danger: float,
        novelty: float,
        object_value: float,
        level_progress: Optional[float],
    ):
        danger = clamp(danger)
        novelty = clamp(novelty)
        object_value = max(
            -1.0,
            min(1.0, float(object_value)),
        )

        progress = (
            0.0
            if level_progress is None
            else clamp(level_progress)
        )

        # Smooth updates rather than hard switches.
        target_survive = clamp(
            0.55 + danger * 0.45
        )

        target_progress = clamp(
            0.65 + progress * 0.25
        )

        target_explore = clamp(
            self.curiosity
            * novelty
            * (1.0 - danger * 0.75)
        )

        target_collect = clamp(
            max(0.0, object_value)
            * (0.55 + self.energy * 0.45)
        )

        targets = {
            "survive": target_survive,
            "progress": target_progress,
            "explore": target_explore,
            "collect": target_collect,
        }

        for key, target in targets.items():
            old = float(
                self.goals.get(
                    key,
                    target,
                )
            )

            self.goals[key] = clamp(
                old * 0.88
                + target * 0.12
            )

    def dominant_goal(self) -> str:
        return max(
            self.goals,
            key=self.goals.get,
        )

    # ------------------------------------------------------------------
    # REPLAY MEMORY
    # ------------------------------------------------------------------

    def _snapshot_state(
        self,
        object_type: str,
        distance: float,
        level_progress: Optional[float],
    ) -> Dict[str, Any]:
        return {
            "object": str(
                object_type
            ).lower(),
            "family": self.object_family(
                object_type
            ),
            "distance": clamp(
                distance
            ),
            "mode": self.game_mode,
            "gravity": self.gravity,
            "speed_multiplier": self.speed_multiplier,
            "level_progress": (
                None
                if level_progress is None
                else clamp(level_progress)
            ),
            "goal": self.dominant_goal(),
        }

    def add_replay(
        self,
        state: Dict[str, Any],
        action: str,
        reward: float,
        success: bool,
        next_state: Optional[Dict[str, Any]] = None,
    ):
        item = {
            "state": state,
            "action": str(action).lower(),
            "reward": max(
                -1.0,
                min(1.0, float(reward)),
            ),
            "success": bool(success),
            "next_state": next_state,
            "priority": clamp(
                abs(float(reward))
                + (0.35 if not success else 0.15),
                0.0,
                1.0,
            ),
        }

        self.replay_memory.append(
            item
        )

        if len(self.replay_memory) > self.MAX_REPLAY:
            # Keep high-priority and recent experiences.
            ranked = sorted(
                enumerate(self.replay_memory),
                key=lambda pair: (
                    pair[1].get(
                        "priority",
                        0.0,
                    ),
                    pair[0] / max(
                        1,
                        len(self.replay_memory),
                    ),
                ),
                reverse=True,
            )

            keep_indices = sorted(
                idx
                for idx, _ in ranked[:self.MAX_REPLAY]
            )

            self.replay_memory = [
                self.replay_memory[i]
                for i in keep_indices
            ]

    # ------------------------------------------------------------------
    # MENTAL ROLLOUT / WORLD MODEL
    # ------------------------------------------------------------------

    def mental_rollout(
        self,
        current_object: str,
        depth: int = 4,
    ) -> Dict[str, Any]:
        depth = max(
            1,
            min(6, int(depth)),
        )

        sequence = self.predict_sequence(
            current_object,
            steps=depth,
        )

        expected_risk = 0.0
        expected_value = 0.0
        cumulative_probability = 1.0

        imagined = []

        for item in sequence:
            obj = item["object"]

            p = clamp(
                item.get(
                    "probability",
                    0.0,
                )
            )

            cumulative_probability *= p

            danger = self._danger_of(
                obj
            )

            value = self._value_of(
                obj
            )

            expected_risk += (
                cumulative_probability
                * danger
            )

            expected_value += (
                cumulative_probability
                * value
            )

            imagined.append({
                "object": obj,
                "probability": p,
                "cumulative_probability": cumulative_probability,
                "danger": danger,
                "value": value,
            })

        expected_risk = clamp(
            expected_risk
            / max(1, len(imagined))
        )

        expected_value = max(
            -1.0,
            min(
                1.0,
                expected_value
                / max(1, len(imagined)),
            ),
        )

        if expected_risk >= 0.65:
            suggestion = "prepare"
        elif expected_value > 0.35:
            suggestion = "collect"
        else:
            suggestion = "continue"

        return {
            "sequence": imagined,
            "expected_risk": expected_risk,
            "expected_value": expected_value,
            "suggestion": suggestion,
        }

    # ------------------------------------------------------------------
    # META-ARBITRATION
    # ------------------------------------------------------------------

    def _apply_family_skill(
        self,
        base: Dict[str, Any],
        family_skill: Dict[str, Any],
    ):
        if not family_skill.get(
            "found",
            False,
        ):
            return base

        conf = float(
            family_skill.get(
                "confidence",
                0.0,
            )
        )

        if conf < 0.62:
            return base

        death_conf = float(
            base.get(
                "death_correction",
                {},
            ).get(
                "confidence",
                0.0,
            )
        )

        route_conf = float(
            base.get(
                "route",
                {},
            ).get(
                "confidence",
                0.0,
            )
        )

        global_conf = float(
            base.get(
                "global_skill",
                {},
            ).get(
                "confidence",
                0.0,
            )
        )

        # Exact / stronger memories win.
        if conf <= max(
            death_conf,
            route_conf,
            global_conf,
        ):
            return base

        if (
            base.get("escape", False)
            or base.get("action") == "escape"
        ):
            return base

        action = str(
            family_skill.get(
                "action",
                "wait",
            )
        )

        if self.game_mode in (
            "cube",
            "ufo",
        ):
            if action in (
                "jump",
                "flap",
            ):
                mapped = (
                    "jump"
                    if self.game_mode == "cube"
                    else "flap"
                )

                base["control"] = {
                    "action": mapped,
                    "jump": True,
                    "hold": False,
                    "vertical": 0.0,
                }

                base["action"] = mapped
                base["jump"] = True
                base["hold"] = False

        elif self.game_mode in (
            "fly",
            "ship",
        ):
            if action in (
                "flap",
                "thrust",
                "jump",
            ):
                mapped = (
                    "flap"
                    if self.game_mode == "fly"
                    else "thrust"
                )

                strength = clamp(
                    family_skill.get(
                        "preferred_control",
                        0.6,
                    )
                )

                sign = (
                    1.0
                    if self.gravity >= 0
                    else -1.0
                )

                base["control"] = {
                    "action": mapped,
                    "jump": False,
                    "hold": True,
                    "vertical": sign * strength,
                }

                base["action"] = mapped
                base["jump"] = False
                base["hold"] = True
                base["vertical"] = sign * strength

        base["confidence"] = max(
            base.get(
                "confidence",
                0.0,
            ),
            conf,
        )

        return base

    def decide_game_action(
        self,
        object_type: str,
        distance: float,
        speed: float = 0.5,
        danger: Optional[float] = None,
        vision_motion: float = 0.5,
        looming: float = 0.0,
        dt: float = 0.016,

        music_id: Optional[str] = None,
        bpm: float = 120.0,
        beat_phase: float = 0.0,
        beat_strength: float = 0.0,

        game_mode: Optional[str] = None,
        gravity: Optional[float] = None,
        speed_multiplier: Optional[float] = None,

        level_id: Optional[str] = None,
        level_progress: Optional[float] = None,

        # v12
        object_value: float = 0.0,
    ) -> Dict[str, Any]:

        if danger is None:
            danger = self._danger_of(
                object_type
            )

        danger = clamp(
            danger
        )

        novelty = self.novelty_score(
            object_type
        )

        self.update_goals(
            danger=danger,
            novelty=novelty,
            object_value=object_value,
            level_progress=level_progress,
        )

        base = super().decide_game_action(
            object_type=object_type,
            distance=distance,
            speed=speed,
            danger=danger,
            vision_motion=vision_motion,
            looming=looming,
            dt=dt,
            music_id=music_id,
            bpm=bpm,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
            game_mode=game_mode,
            gravity=gravity,
            speed_multiplier=speed_multiplier,
            level_id=level_id,
            level_progress=level_progress,
        )

        family = self.recall_family_skill(
            object_type
        )

        base["family_skill"] = family

        base = self._apply_family_skill(
            base,
            family,
        )

        imagination = self.mental_rollout(
            object_type,
            depth=4,
        )

        # Future danger gives a small preparation bonus.
        if (
            imagination["expected_risk"] > 0.55
            and not base.get(
                "escape",
                False,
            )
        ):
            base["confidence"] = max(
                base.get(
                    "confidence",
                    0.0,
                ),
                clamp(
                    imagination[
                        "expected_risk"
                    ] * 0.85
                ),
            )

        base["imagination"] = imagination

        base["novelty"] = novelty
        base["curiosity"] = self.curiosity

        base["goals"] = dict(
            self.goals
        )

        base["dominant_goal"] = (
            self.dominant_goal()
        )

        base["prediction_quality"] = (
            self.prediction_accuracy()
        )

        self.last_meta_decision = {
            "action": base.get(
                "action",
                "wait",
            ),
            "confidence": base.get(
                "confidence",
                0.0,
            ),
            "goal": base[
                "dominant_goal"
            ],
            "novelty": novelty,
        }

        self._last_state_snapshot = (
            self._snapshot_state(
                object_type,
                distance,
                level_progress,
            )
        )

        return base

    # ------------------------------------------------------------------
    # LEARNING FROM RESULT
    # ------------------------------------------------------------------

    def learn_game_result(
        self,
        object_type: str,
        action: str,
        success: bool,
        timing: float = 0.5,
        progress: float = 0.0,

        music_id: Optional[str] = None,
        beat_phase: Optional[float] = None,
        beat_strength: float = 1.0,

        game_mode: Optional[str] = None,
        control_strength: float = 0.5,
    ):
        # Reward aligned with previous versions.
        reward = (
            0.35 + clamp(progress) * 0.35
            if success
            else -0.45 + clamp(progress) * 0.20
        )

        super().learn_game_result(
            object_type=object_type,
            action=action,
            success=success,
            timing=timing,
            progress=progress,
            music_id=music_id,
            beat_phase=beat_phase,
            beat_strength=beat_strength,
            game_mode=game_mode,
            control_strength=control_strength,
        )

        self.learn_family_skill(
            object_type=object_type,
            action=action,
            success=success,
            control_strength=control_strength,
            reward=reward,
        )

        key = self._novelty_key(
            object_type
        )

        data = self.novelty_memory.setdefault(
            key,
            {
                "visits": 0,
                "reward_sum": 0.0,
                "successes": 0,
                "failures": 0,
            },
        )

        if success:
            data["successes"] += 1
        else:
            data["failures"] += 1

        data["reward_sum"] += reward

        if self._last_state_snapshot:
            self.add_replay(
                state=self._last_state_snapshot,
                action=action,
                reward=reward,
                success=success,
                next_state=None,
            )

        # Successful familiar tasks slowly reduce curiosity;
        # failures/novelty keep it alive.
        if success:
            self.curiosity = clamp(
                self.curiosity * 0.997
            )
        else:
            self.curiosity = clamp(
                self.curiosity + 0.003
            )

    def on_death(
        self,
        object_type: str,
        distance: float,
        progress: float,
        action: Optional[str] = None,
        cause: str = "collision",
    ) -> Dict[str, Any]:

        before_snapshot = self._snapshot_state(
            object_type,
            distance,
            progress,
        )

        result = super().on_death(
            object_type=object_type,
            distance=distance,
            progress=progress,
            action=action,
            cause=cause,
        )

        chosen_action = (
            action
            if action is not None
            else (
                self.last_meta_decision[
                    "action"
                ]
                if self.last_meta_decision
                else "wait"
            )
        )

        self.add_replay(
            state=before_snapshot,
            action=chosen_action,
            reward=-0.85,
            success=False,
            next_state=None,
        )

        self.curiosity = clamp(
            self.curiosity + 0.005
        )

        return result

    # ------------------------------------------------------------------
    # SLEEP / CONSOLIDATION / EXPERIENCE REPLAY
    # ------------------------------------------------------------------

    def sleep(
        self,
        replay_samples: int = 64,
    ) -> Dict[str, Any]:
        """
        Offline consolidation.
        Replays high-priority experiences and compacts memories.
        """
        replay_samples = max(
            0,
            min(
                int(replay_samples),
                len(self.replay_memory),
            ),
        )

        ranked = sorted(
            self.replay_memory,
            key=lambda item: float(
                item.get(
                    "priority",
                    0.0,
                )
            ),
            reverse=True,
        )

        replayed = 0

        for item in ranked[:replay_samples]:
            state = item.get(
                "state",
                {},
            )

            object_type = state.get(
                "object"
            )

            if not object_type:
                continue

            # Restore only high-level mode context for replay.
            old_mode = self.game_mode
            old_gravity = self.gravity
            old_speed = self.speed_multiplier

            try:
                self.set_game_context(
                    game_mode=state.get(
                        "mode",
                        self.game_mode,
                    ),
                    gravity=state.get(
                        "gravity",
                        self.gravity,
                    ),
                    speed_multiplier=state.get(
                        "speed_multiplier",
                        self.speed_multiplier,
                    ),
                )

                self.learn_family_skill(
                    object_type=object_type,
                    action=item.get(
                        "action",
                        "wait",
                    ),
                    success=bool(
                        item.get(
                            "success",
                            False,
                        )
                    ),
                    control_strength=0.5,
                    reward=float(
                        item.get(
                            "reward",
                            0.0,
                        )
                    ),
                )

                replayed += 1

            finally:
                self.game_mode = old_mode
                self.gravity = old_gravity
                self.speed_multiplier = old_speed

        route_summary = (
            self.consolidate_routes()
        )

        global_summary = (
            self.consolidate_global_skills()
        )

        memory_summary = (
            self.consolidate_memory()
        )

        family_before = len(
            self.family_skill_memory
        )

        self._trim_family_skills()
        self._trim_novelty()
        self._trim_prediction_calibration()

        # Keep replay buffer bounded and bias toward important items.
        if len(self.replay_memory) > self.MAX_REPLAY:
            self.replay_memory = sorted(
                self.replay_memory,
                key=lambda x: float(
                    x.get(
                        "priority",
                        0.0,
                    )
                ),
                reverse=True,
            )[:self.MAX_REPLAY]

        return {
            "replayed": replayed,
            "routes": route_summary,
            "global_skills": global_summary,
            "memory": memory_summary,
            "family_skills": len(
                self.family_skill_memory
            ),
            "family_before_trim": family_before,
            "replay_size": len(
                self.replay_memory
            ),
        }

    # ------------------------------------------------------------------
    # BRAIN REPORT
    # ------------------------------------------------------------------

    def brain_report(
        self,
    ) -> Dict[str, Any]:
        prediction = self.prediction_accuracy()

        route_count = sum(
            len(v)
            for v in self.route_memory.values()
        )

        return {
            "version": self.VERSION,
            "age": self.age,
            "energy": self.energy,
            "memory_food": self.memory_food,
            "dopamine": self.dopamine,
            "curiosity": self.curiosity,
            "dominant_goal": self.dominant_goal(),
            "goals": dict(self.goals),

            "memory_counts": {
                "visual_objects": len(
                    self.visual_memory
                ),
                "patterns": len(
                    self.pattern_memory
                ),
                "episodes": len(
                    self.episode_memory
                ),
                "routes": route_count,
                "levels_with_routes": len(
                    self.route_memory
                ),
                "global_skills": len(
                    self.global_skill_library
                ),
                "family_skills": len(
                    self.family_skill_memory
                ),
                "death_contexts": len(
                    self.death_memory
                ),
                "novelty_contexts": len(
                    self.novelty_memory
                ),
                "replay": len(
                    self.replay_memory
                ),
            },

            "prediction": prediction,

            "mode": {
                "name": self.game_mode,
                "gravity": self.gravity,
                "speed_multiplier": self.speed_multiplier,
            },

            "total_deaths": self.total_deaths,
            "total_spikes": self.total_spikes,
        }

    # ------------------------------------------------------------------
    # SAVE
    # ------------------------------------------------------------------

    def save_state(self):
        state = super().save_state()

        state.update({
            "version": self.VERSION,
            "novelty_memory": self.novelty_memory,
            "curiosity": self.curiosity,
            "family_skill_memory": self.family_skill_memory,
            "prediction_calibration": self.prediction_calibration,
            "replay_memory": self.replay_memory[-self.MAX_REPLAY:],
            "goals": self.goals,
        })

        return state

    def save_to_file(
        self,
        path="fly_brain_memory_v12.json",
    ):
        with open(
            path,
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                self.save_state(),
                f,
                ensure_ascii=False,
                indent=2,
            )

    @classmethod
    def load_from_file(
        cls,
        path="fly_brain_memory_v12.json",
    ):
        try:
            with open(
                path,
                "r",
                encoding="utf-8",
            ) as f:
                return cls(
                    json.load(f)
                )
        except (
            FileNotFoundError,
            json.JSONDecodeError,
            TypeError,
            ValueError,
        ):
            return cls()


if __name__ == "__main__":
    brain = FlyBrainModel()

    # ==============================================================
    # TEST 1: Object-family transfer
    # Train normal spike, then use unseen mega_spike.
    # ==============================================================
    brain.set_game_context(
        game_mode="cube",
        gravity=1.0,
        speed_multiplier=1.0,
    )

    for _ in range(24):
        brain.learn_game_result(
            object_type="spike",
            action="jump",
            success=True,
            timing=.42,
            progress=.7,
            game_mode="cube",
            control_strength=.9,
        )

    family = brain.recall_family_skill(
        "mega_spike"
    )

    assert family["found"]
    assert family["family"] == "spike"
    assert family["action"] == "jump"
    assert family["confidence"] > .8

    # ==============================================================
    # TEST 2: Mental rollout / future risk
    # Teach transitions:
    # marker -> portal -> saw
    # ==============================================================
    for _ in range(30):
        brain.reset_activity()

        for _ in range(4):
            brain.step(
                object_type="marker",
                object_distance=.6,
                object_danger=.0,
                vision_motion=.1,
            )

        for _ in range(4):
            brain.step(
                object_type="portal",
                object_distance=.5,
                object_danger=.1,
                vision_motion=.1,
            )

        for _ in range(4):
            brain.step(
                object_type="saw",
                object_distance=.4,
                object_danger=.95,
                vision_motion=.7,
                looming=.2,
            )

    rollout = brain.mental_rollout(
        "marker",
        depth=3,
    )

    assert len(
        rollout["sequence"]
    ) >= 2

    assert (
        rollout["sequence"][0]["object"]
        == "portal"
    )

    assert any(
        item["object"] == "saw"
        for item in rollout["sequence"]
    )

    assert rollout["expected_risk"] > 0.0

    # ==============================================================
    # TEST 3: Prediction calibration
    # Repeatedly trigger marker -> portal.
    # ==============================================================
    for _ in range(20):
        brain.reset_activity()

        # Need known transition before prediction can be registered.
        brain.observe_object(
            "marker",
            .6,
            .0,
        )

        brain.observe_object(
            "portal",
            .5,
            .1,
        )

    calibration = brain.prediction_accuracy()

    assert calibration["samples"] > 0
    assert calibration["accuracy"] >= .7

    # ==============================================================
    # TEST 4: Family transfer affects new unknown spike type.
    # ==============================================================
    brain.reset_activity()

    decision = None

    for _ in range(5):
        decision = brain.decide_game_action(
            object_type="mega_spike",
            distance=.48,
            speed=.4,
            danger=.05,
            vision_motion=.05,
            looming=0.0,
            game_mode="cube",
            gravity=1.0,
            speed_multiplier=1.0,
            level_id="brand_new_level",
            level_progress=.2,
        )

    assert decision["family_skill"]["found"]
    assert decision["action"] == "jump"
    assert decision["jump"] is True

    # ==============================================================
    # TEST 5: Replay + sleep
    # ==============================================================
    before_replay = len(
        brain.replay_memory
    )

    for _ in range(12):
        brain.learn_game_result(
            object_type="mega_spike",
            action="jump",
            success=True,
            timing=.42,
            progress=.8,
            game_mode="cube",
            control_strength=.9,
        )

    assert len(
        brain.replay_memory
    ) > before_replay

    sleep_summary = brain.sleep(
        replay_samples=16
    )

    assert sleep_summary["replayed"] > 0

    # ==============================================================
    # TEST 6: Novelty falls with experience.
    # ==============================================================
    brain.reset_activity()

    novelty_before = brain.novelty_score(
        "brand_new_orb"
    )

    brain.observe_object(
        "brand_new_orb",
        .6,
        .0,
    )

    # Change away and back so it counts as another encounter.
    brain.observe_object(
        "marker",
        .6,
        .0,
    )

    brain.observe_object(
        "brand_new_orb",
        .6,
        .0,
    )

    novelty_after = brain.novelty_score(
        "brand_new_orb"
    )

    assert novelty_after < novelty_before

    # ==============================================================
    # TEST 7: Save / load all v12 memories.
    # ==============================================================
    saved = brain.save_state()
    restored = FlyBrainModel(
        saved
    )

    restored_family = (
        restored.recall_family_skill(
            "mega_spike"
        )
    )

    assert restored_family["found"]
    assert restored_family["action"] == "jump"
    assert len(
        restored.replay_memory
    ) == len(
        brain.replay_memory
    )

    report = restored.brain_report()

    assert report["version"] == 12
    assert (
        report[
            "memory_counts"
        ]["family_skills"]
        > 0
    )

    print("FLY BRAIN V12 SELF TEST")
    print(
        "family transfer:",
        family["family"],
        family["action"],
        round(
            family["confidence"],
            3,
        ),
    )
    print(
        "rollout:",
        [
            item["object"]
            for item in rollout["sequence"]
        ],
    )
    print(
        "future risk:",
        round(
            rollout["expected_risk"],
            3,
        ),
    )
    print(
        "prediction accuracy:",
        round(
            calibration["accuracy"],
            3,
        ),
        "samples=",
        calibration["samples"],
    )
    print(
        "mega_spike decision:",
        decision["action"],
        "confidence=",
        round(
            decision["confidence"],
            3,
        ),
    )
    print(
        "novelty:",
        round(
            novelty_before,
            3,
        ),
        "->",
        round(
            novelty_after,
            3,
        ),
    )
    print(
        "sleep:",
        sleep_summary,
    )
    print(
        "brain report:",
        report,
    )
    print("OK: FlyBrain v12 works")
