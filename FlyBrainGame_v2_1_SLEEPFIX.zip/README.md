# FlyBrain Game v2.1 — Sleep Fix

Что добавлено:

- Главное меню
- STORY
- ENDLESS
- EDITOR
- BRAIN
- SLEEP
- Режимы cube / ship / fly / wave / ufo
- Порталы режима
- Портал гравитации
- Портал скорости
- Coin
- Food
- Orb
- Pad
- Finish
- Память смертей
- Память маршрутов
- Глобальные навыки
- Семейства похожих препятствий
- Replay memory
- Brain report
- AI ON / OFF
- Пользовательский мини-редактор

## Исправленный SLEEP

SLEEP теперь не скрытая функция.

После нажатия:
1. игра останавливается;
2. вызывается `brain.sleep(replay_samples=64)`;
3. выполняется replay и консолидация;
4. мозг сохраняется;
5. открывается отдельный экран BRAIN SLEEP;
6. на экране видно:
   - replayed experiences
   - replay memory size
   - routes kept
   - global skills
   - episodes
   - patterns
7. кнопка WAKE возвращает назад.

## APK

GitHub:
Actions -> Build FlyBrain Game APK -> Run workflow

После сборки скачай:
FlyBrain-Game-v2.1-APK
