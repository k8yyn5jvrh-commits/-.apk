import json
from fly_brain_model_v12 import FlyBrainModel

brain = None

def _safe_load(saved_json):
    if not saved_json:
        return {}
    try:
        obj = json.loads(saved_json)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}

def init_brain(saved_json=""):
    global brain
    brain = FlyBrainModel(_safe_load(saved_json))
    return json.dumps(brain.brain_report(), ensure_ascii=False)

def _ensure():
    global brain
    if brain is None:
        brain = FlyBrainModel()
    return brain

def decide(object_type, distance, speed, danger, progress,
           mode="cube", gravity=1.0, speed_multiplier=1.0,
           music_id="demo", bpm=150.0, beat_phase=0.0):
    b = _ensure()
    out = b.decide_game_action(
        object_type=str(object_type),
        distance=float(distance),
        speed=float(speed),
        danger=float(danger),
        vision_motion=max(0.1, min(1.0, float(speed))),
        looming=max(0.0, min(1.0, 1.0 - float(distance))),
        game_mode=str(mode),
        gravity=float(gravity),
        speed_multiplier=float(speed_multiplier),
        level_id="android_demo",
        level_progress=float(progress),
        music_id=str(music_id),
        bpm=float(bpm),
        beat_phase=float(beat_phase),
        beat_strength=1.0,
    )
    compact = {
        "action": out.get("action", "wait"),
        "jump": bool(out.get("jump", False)),
        "hold": bool(out.get("hold", False)),
        "vertical": float(out.get("vertical", 0.0)),
        "confidence": float(out.get("confidence", 0.0)),
        "novelty": float(out.get("novelty", 0.0)),
        "goal": out.get("dominant_goal", ""),
    }
    return json.dumps(compact, ensure_ascii=False)

def learn_success(object_type, action, progress, timing=0.42):
    b = _ensure()
    b.learn_game_result(
        object_type=str(object_type),
        action=str(action),
        success=True,
        timing=float(timing),
        progress=float(progress),
        game_mode=b.game_mode,
        control_strength=0.9 if str(action) in ("jump", "flap", "thrust") else 0.3,
    )
    return json.dumps(b.brain_report(), ensure_ascii=False)

def learn_failure(object_type, action, progress, distance, cause="collision"):
    b = _ensure()
    out = b.on_death(
        object_type=str(object_type),
        distance=float(distance),
        progress=float(progress),
        action=str(action),
        cause=str(cause),
    )
    return json.dumps({
        "death": out.get("death"),
        "correction": out.get("correction"),
    }, ensure_ascii=False)

def start_route():
    b = _ensure()
    try:
        b.start_episode("android_demo")
    except Exception:
        pass
    try:
        b.start_route("android_demo")
    except Exception:
        pass
    return "ok"

def finish_route(success=True, progress=1.0):
    b = _ensure()
    try:
        if b.current_episode is not None:
            b.finish_episode(bool(success), 1.0 if success else -0.8, float(progress))
    except Exception:
        pass
    try:
        if b.current_route is not None:
            b.finish_route(bool(success), 1.0 if success else -0.8, float(progress))
    except Exception:
        pass
    return "ok"

def sleep_brain():
    return json.dumps(_ensure().sleep(replay_samples=32), ensure_ascii=False)

def report():
    return json.dumps(_ensure().brain_report(), ensure_ascii=False)

def save_json():
    return json.dumps(_ensure().save_state(), ensure_ascii=False)

def factory_reset():
    global brain
    brain = FlyBrainModel()
    return json.dumps(brain.brain_report(), ensure_ascii=False)
