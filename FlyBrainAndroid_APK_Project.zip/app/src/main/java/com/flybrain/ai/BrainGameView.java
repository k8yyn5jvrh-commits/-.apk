package com.flybrain.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;
import java.util.Random;

public class BrainGameView extends View {

    private static class Obstacle {
        float x, w, h;
        boolean passed = false;
        String type;

        Obstacle(float x, float w, float h, String type) {
            this.x = x;
            this.w = w;
            this.h = h;
            this.type = type;
        }
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private final ArrayList<Obstacle> obstacles = new ArrayList<>();

    private Bitmap flyBitmap;
    private PyObject bridge;
    private SharedPreferences prefs;

    private long lastFrameNs = 0;
    private long lastBrainCallNs = 0;

    private float flyX = 220f;
    private float flyY = 0f;
    private float flyVy = 0f;
    private float groundY = 0f;

    private final float flyW = 92f;
    private final float flyH = 76f;

    private float worldSpeed = 380f;
    private final float gravity = 1800f;
    private final float jumpVelocity = -720f;

    private int score = 0;
    private int deaths = 0;
    private int generation = 1;
    private float progress = 0f;

    private boolean dead = false;
    private long deadAtNs = 0;

    private String lastAction = "wait";
    private String dominantGoal = "progress";
    private float confidence = 0f;
    private float novelty = 0f;

    private final RectF resetButton = new RectF();
    private final RectF sleepButton = new RectF();

    public BrainGameView(Context context) {
        super(context);
        setFocusable(true);

        text.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.BOLD));
        text.setTextSize(27f);

        flyBitmap = BitmapFactory.decodeResource(
            getResources(),
            getResources().getIdentifier("fly", "drawable", context.getPackageName())
        );

        prefs = context.getSharedPreferences("flybrain", Context.MODE_PRIVATE);

        try {
            Python py = Python.getInstance();
            bridge = py.getModule("android_bridge");
            bridge.callAttr("init_brain", prefs.getString("brain_json", ""));
        } catch (Exception e) {
            lastAction = "Python error";
        }

        resetWorld(true);
    }

    private void resetWorld(boolean newRoute) {
        obstacles.clear();
        flyVy = 0f;
        dead = false;
        progress = 0f;

        if (getHeight() > 0) {
            groundY = getHeight() * 0.78f;
            flyY = groundY - flyH;
        }

        float start = Math.max(900f, getWidth() + 250f);
        for (int i = 0; i < 6; i++) {
            spawnObstacle(start + i * 500f);
        }

        if (newRoute && bridge != null) {
            try { bridge.callAttr("start_route"); } catch (Exception ignored) {}
        }

        invalidate();
    }

    private void spawnObstacle(float x) {
        String[] types = {"spike", "double_spike", "mega_spike", "saw"};
        String type = types[random.nextInt(types.length)];

        float h = type.equals("saw") ? 78f :
                  type.equals("mega_spike") ? 110f :
                  type.equals("double_spike") ? 90f : 82f;

        float w = type.equals("double_spike") ? 100f : 66f;
        obstacles.add(new Obstacle(x, w, h, type));
    }

    private void jump() {
        if (dead) return;
        if (flyY >= groundY - flyH - 8f) {
            flyVy = jumpVelocity;
        }
    }

    private Obstacle nearestObstacle() {
        Obstacle best = null;
        float bestDx = Float.MAX_VALUE;
        for (Obstacle o : obstacles) {
            float dx = o.x - flyX;
            if (dx > -o.w && dx < bestDx) {
                bestDx = dx;
                best = o;
            }
        }
        return best;
    }

    private float obstacleDanger(String type) {
        if (type == null) return 0f;
        if (type.contains("spike")) return 0.96f;
        if (type.equals("saw")) return 1.0f;
        return 0.3f;
    }

    private float beatPhase() {
        double seconds = System.nanoTime() / 1_000_000_000.0;
        double beatLength = 60.0 / 150.0;
        return (float)((seconds % beatLength) / beatLength);
    }

    private void callBrain(Obstacle o, long nowNs) {
        if (bridge == null || o == null || dead) return;
        if (nowNs - lastBrainCallNs < 50_000_000L) return;
        lastBrainCallNs = nowNs;

        float dx = Math.max(0f, o.x - flyX);
        float distance = Math.min(1f, dx / Math.max(500f, getWidth() * 0.45f));
        float speedNorm = Math.min(1f, worldSpeed / 700f);

        try {
            JSONObject j = new JSONObject(
                bridge.callAttr(
                    "decide",
                    o.type,
                    distance,
                    speedNorm,
                    obstacleDanger(o.type),
                    progress,
                    "cube",
                    1.0,
                    1.0,
                    "demo_track",
                    150.0,
                    beatPhase()
                ).toString()
            );

            lastAction = j.optString("action", "wait");
            confidence = (float)j.optDouble("confidence", 0.0);
            novelty = (float)j.optDouble("novelty", 0.0);
            dominantGoal = j.optString("goal", "progress");

            if (j.optBoolean("jump", false)) jump();

        } catch (Exception e) {
            lastAction = "brain error";
        }
    }

    private void learnSuccess(Obstacle o) {
        if (bridge == null) return;
        try {
            bridge.callAttr("learn_success", o.type, lastAction, progress, 0.42);
        } catch (Exception ignored) {}
    }

    private void die(Obstacle o, long nowNs) {
        if (dead) return;

        dead = true;
        deaths++;
        deadAtNs = nowNs;

        if (bridge != null) {
            try {
                float dx = Math.abs(o.x - flyX);
                float dist = Math.min(1f, dx / 500f);

                bridge.callAttr(
                    "learn_failure",
                    o.type,
                    lastAction,
                    progress,
                    dist,
                    "collision"
                );

                bridge.callAttr("finish_route", false, progress);
            } catch (Exception ignored) {}
        }

        saveBrain();
    }

    public void saveBrain() {
        if (bridge == null || prefs == null) return;
        try {
            prefs.edit()
                 .putString("brain_json", bridge.callAttr("save_json").toString())
                 .apply();
        } catch (Exception ignored) {}
    }

    public void resumeGame() {
        lastFrameNs = 0;
        invalidate();
    }

    private void brainSleep() {
        if (bridge == null) return;
        try {
            bridge.callAttr("sleep_brain");
            saveBrain();
        } catch (Exception ignored) {}
    }

    private void factoryReset() {
        if (bridge != null) {
            try { bridge.callAttr("factory_reset"); } catch (Exception ignored) {}
        }
        prefs.edit().remove("brain_json").apply();
        score = 0;
        deaths = 0;
        generation = 1;
        resetWorld(true);
    }

    private boolean collides(Obstacle o) {
        RectF flyRect = new RectF(
            flyX + 13f,
            flyY + 8f,
            flyX + flyW - 10f,
            flyY + flyH - 8f
        );

        RectF obstacleRect = new RectF(
            o.x + 7f,
            groundY - o.h,
            o.x + o.w - 7f,
            groundY
        );

        return RectF.intersects(flyRect, obstacleRect);
    }

    private void update(float dt, long nowNs) {
        if (getWidth() <= 0 || getHeight() <= 0) return;

        if (groundY == 0f) {
            groundY = getHeight() * 0.78f;
            flyY = groundY - flyH;
        }

        if (dead) {
            if (nowNs - deadAtNs > 900_000_000L) {
                generation++;
                resetWorld(true);
            }
            return;
        }

        progress = Math.min(1f, progress + dt * 0.027f);

        flyVy += gravity * dt;
        flyY += flyVy * dt;

        if (flyY >= groundY - flyH) {
            flyY = groundY - flyH;
            flyVy = 0f;
        }

        callBrain(nearestObstacle(), nowNs);

        float farthest = 0f;

        for (Obstacle o : obstacles) {
            o.x -= worldSpeed * dt;
            farthest = Math.max(farthest, o.x);

            if (!o.passed && o.x + o.w < flyX) {
                o.passed = true;
                score++;
                learnSuccess(o);
            }

            if (collides(o)) {
                die(o, nowNs);
            }
        }

        Iterator<Obstacle> it = obstacles.iterator();
        int removed = 0;

        while (it.hasNext()) {
            Obstacle o = it.next();
            if (o.x + o.w < -100f) {
                it.remove();
                removed++;
            }
        }

        for (int i = 0; i < removed; i++) {
            farthest = Math.max(farthest, getWidth() + 600f);
            spawnObstacle(farthest + 420f + random.nextInt(240));
        }

        if (progress >= 1f) {
            if (bridge != null) {
                try {
                    bridge.callAttr("finish_route", true, 1.0);
                    bridge.callAttr("sleep_brain");
                } catch (Exception ignored) {}
            }
            saveBrain();
            generation++;
            resetWorld(true);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);

        long now = System.nanoTime();
        if (lastFrameNs == 0) lastFrameNs = now;

        float dt = Math.min(
            0.035f,
            (now - lastFrameNs) / 1_000_000_000f
        );

        lastFrameNs = now;
        update(dt, now);

        c.drawColor(Color.rgb(8, 11, 18));

        p.setColor(Color.rgb(22, 32, 48));
        p.setStrokeWidth(1f);

        for (int x = 0; x < getWidth(); x += 70) c.drawLine(x, 0, x, groundY, p);
        for (int y = 0; y < groundY; y += 70) c.drawLine(0, y, getWidth(), y, p);

        p.setColor(Color.rgb(45, 220, 120));
        p.setStrokeWidth(5f);
        c.drawLine(0, groundY, getWidth(), groundY, p);

        for (Obstacle o : obstacles) {
            if (o.type.equals("saw")) {
                p.setColor(Color.rgb(255, 100, 100));
                c.drawCircle(
                    o.x + o.w / 2f,
                    groundY - o.h / 2f,
                    o.w / 2f,
                    p
                );
                p.setColor(Color.rgb(8, 11, 18));
                c.drawCircle(
                    o.x + o.w / 2f,
                    groundY - o.h / 2f,
                    o.w / 5f,
                    p
                );
            } else {
                p.setColor(Color.rgb(255, 90, 105));
                Path path = new Path();
                path.moveTo(o.x, groundY);
                path.lineTo(o.x + o.w / 2f, groundY - o.h);
                path.lineTo(o.x + o.w, groundY);
                path.close();
                c.drawPath(path, p);
            }
        }

        if (flyBitmap != null) {
            Rect src = new Rect(
                0, 0,
                flyBitmap.getWidth(),
                flyBitmap.getHeight()
            );
            RectF dst = new RectF(
                flyX,
                flyY,
                flyX + flyW,
                flyY + flyH
            );
            c.drawBitmap(flyBitmap, src, dst, p);
        }

        p.setColor(Color.argb(180, 5, 8, 15));
        c.drawRoundRect(
            new RectF(22, 20, 690, 188),
            22, 22, p
        );

        text.setColor(Color.WHITE);
        text.setTextSize(27f);
        c.drawText("FlyBrain AI v12", 45, 58, text);

        text.setTextSize(22f);
        c.drawText(
            String.format(
                Locale.US,
                "Score %d   Deaths %d   Gen %d",
                score, deaths, generation
            ),
            45, 92, text
        );

        c.drawText(
            String.format(
                Locale.US,
                "Action %-9s  conf %.2f  novelty %.2f",
                lastAction, confidence, novelty
            ),
            45, 123, text
        );

        c.drawText(
            "Goal: " + dominantGoal,
            45, 154, text
        );

        p.setColor(Color.rgb(28, 40, 58));
        c.drawRoundRect(
            new RectF(45, 164, 620, 176),
            7, 7, p
        );

        p.setColor(Color.rgb(124, 255, 155));
        c.drawRoundRect(
            new RectF(
                45, 164,
                45 + 575 * progress,
                176
            ),
            7, 7, p
        );

        resetButton.set(
            getWidth() - 260, 28,
            getWidth() - 145, 92
        );

        sleepButton.set(
            getWidth() - 135, 28,
            getWidth() - 20, 92
        );

        p.setColor(Color.rgb(42, 52, 72));
        c.drawRoundRect(resetButton, 16, 16, p);
        c.drawRoundRect(sleepButton, 16, 16, p);

        text.setTextSize(19f);
        text.setColor(Color.WHITE);

        c.drawText(
            "RESET",
            resetButton.left + 25,
            resetButton.centerY() + 7,
            text
        );

        c.drawText(
            "SLEEP",
            sleepButton.left + 25,
            sleepButton.centerY() + 7,
            text
        );

        if (dead) {
            p.setColor(Color.argb(175, 20, 0, 5));
            c.drawRect(0, 0, getWidth(), getHeight(), p);

            text.setColor(Color.rgb(255, 110, 120));
            text.setTextSize(58f);
            text.setTextAlign(Paint.Align.CENTER);

            c.drawText(
                "ОШИБКА ЗАПОМНЕНА",
                getWidth() / 2f,
                getHeight() / 2f - 10,
                text
            );

            text.setTextSize(25f);
            text.setColor(Color.WHITE);

            c.drawText(
                "Следующая попытка уже использует память смерти",
                getWidth() / 2f,
                getHeight() / 2f + 38,
                text
            );

            text.setTextAlign(Paint.Align.LEFT);
        }

        postInvalidateOnAnimation();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN) return true;

        float x = event.getX();
        float y = event.getY();

        if (resetButton.contains(x, y)) {
            factoryReset();
            return true;
        }

        if (sleepButton.contains(x, y)) {
            brainSleep();
            return true;
        }

        jump();
        return true;
    }
}
