# FlyBrain AI Android

Готовый Android-проект с FlyBrain v12.

Что есть:
- FlyBrain v12 работает внутри APK через Chaquopy/Python.
- Автоматический мини-уровень с препятствиями.
- Реалистичный спрайт мухи.
- Смерти и успехи обучают мозг.
- Память сохраняется после закрытия приложения.
- SLEEP запускает консолидацию памяти.
- RESET полностью стирает обучение.
- Нажатие по игровому полю — ручной тестовый прыжок.

## Получить APK через GitHub Actions

1. Загрузи содержимое этой папки в GitHub-репозиторий.
2. Открой Actions.
3. Выбери `Build Android APK`.
4. Нажми `Run workflow`.
5. После сборки скачай artifact `FlyBrain-AI-debug-apk`.
6. Внутри будет `app-debug.apk`.

Локальная команда:
`gradle :app:assembleDebug`

APK появится здесь:
`app/build/outputs/apk/debug/app-debug.apk`
