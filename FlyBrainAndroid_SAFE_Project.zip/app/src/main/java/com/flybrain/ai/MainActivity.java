package com.flybrain.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.ScrollView;
import android.widget.TextView;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends Activity {
    private BrainGameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        try {
            hideSystemUI();
            if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
            gameView = new BrainGameView(this);
            setContentView(gameView);
        } catch (Throwable t) {
            showCrashScreen(t);
        }
    }

    private void hideSystemUI() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void showCrashScreen(Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        TextView tv = new TextView(this);
        tv.setText("FlyBrain не смог запуститься.\\n\\n" + t.getClass().getName() + "\\n\\n" + String.valueOf(t.getMessage()) + "\\n\\n--- STACK TRACE ---\\n" + sw);
        tv.setTextColor(Color.WHITE);
        tv.setBackgroundColor(Color.rgb(20, 6, 10));
        tv.setTextSize(15);
        tv.setPadding(32, 32, 32, 32);
        tv.setGravity(Gravity.LEFT);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(tv);
        setContentView(scroll);
    }

    @Override protected void onPause() {
        super.onPause();
        if (gameView != null) try { gameView.saveBrain(); } catch (Throwable ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (gameView != null) try { gameView.resumeGame(); } catch (Throwable ignored) {}
    }
}
